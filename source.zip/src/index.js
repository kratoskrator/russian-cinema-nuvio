'use strict';
var u = require('./utils');
var http = require('./http');
var filmix = require('./filmix');
var seasonvar = require('./seasonvar');
var collaps = require('./collaps');
var kinopub = require('./kinopub');
var hdvb = require('./hdvb');
var media = require('./media');
var DEFAULT_SEASONVAR = 'https://seasonvar.ru';
var DEFAULT_COLLAPS = 'https://api.luxembd.ws';
var DEFAULT_KINOPUB = 'https://api.srvkp.com';
var DEFAULT_HDVB = 'https://apivb.com';

function settings() {
  var root = typeof globalThis !== 'undefined' ? globalThis : {};
  var saved = root.SCRAPER_SETTINGS || {};
  return {
    seasonvarSite: u.siteUrl(saved.seasonvarSite || DEFAULT_SEASONVAR) || DEFAULT_SEASONVAR,
    collapsSite: u.siteUrl(saved.collapsSite || DEFAULT_COLLAPS) || DEFAULT_COLLAPS,
    kinopubApi: String(saved.kinopubApi || DEFAULT_KINOPUB).trim(),
    kinopubToken: String(saved.kinopubToken || '').trim(),
    hdvbApi: String(saved.hdvbApi || DEFAULT_HDVB).trim(),
    hdvbToken: String(saved.hdvbToken || '').trim(),
    filmixTvToken: String(saved.filmixTvToken || '').trim(),
    filmixTvHash: String(saved.filmixTvHash || '').trim(),
    key: String(saved.tmdbApiKey || root.TMDB_API_KEY || '').trim(),
    deadline: Date.now() + 50000
  };
}

function metadata(id, type, cfg) {
  if (!cfg.key) return Promise.reject(new Error('TMDB key unavailable. Enter your own key in Russian Cinema settings.'));
  var token = cfg.key.length > 40;
  var url = 'https://api.themoviedb.org/3/' + type + '/' + encodeURIComponent(id) + '?language=ru-RU&append_to_response=external_ids';
  if (!token) url += '&api_key=' + encodeURIComponent(cfg.key);
  var state = http.session(cfg.deadline);
  var options = { json: true, bearer: token ? cfg.key : '', session: state };
  return http.request(url, options).then(function (data) {
    var imdb = data.external_ids && data.external_ids.imdb_id || data.imdb_id || '';
    return {
      type: type, title: data.title || data.name || '', originalTitle: data.original_title || data.original_name || '',
      year: Number(String(data.release_date || data.first_air_date || '').slice(0, 4)) || null,
      imdb: /^tt\d{7,10}$/.test(imdb) ? imdb : '',
      runtimeSeconds: (type === 'movie' ? Number(data.runtime) || 0 : 0) * 60
    };
  });
}

function client(cfg) {
  var state = http.session(cfg.deadline);
  return { request: function (url, options) {
    options = options || {};
    options.session = state;
    return http.request(url, options);
  } };
}

function source(label, module, meta, season, episode, cfg) {
  return Promise.resolve().then(function () {
    return module.resolve(meta, season, episode, cfg, client(cfg));
  }).then(function (streams) {
    return (Array.isArray(streams) ? streams : []).slice(0, 8).map(function (stream) { stream.sourceName = label; return stream; });
  }).catch(function (error) {
    console.warn('[Russian Cinema / ' + label + '] ' + (error && error.providerSafe ? error.message : 'Source resolution failed.'));
    return [];
  });
}

function playbackHeaders(values) {
  var clean = {};
  Object.keys(values || {}).forEach(function (name) {
    if (/^(?:authorization|cookie|proxy-authorization|x-api-key|token|hash)$/i.test(name)) return;
    clean[name] = values[name];
  });
  return clean;
}

function verify(stream, cfg) {
  if (!stream || !/^https?:\/\/[^\s/?#@]+(?:[/?#][^\s]*)?$/i.test(String(stream.url || ''))) return Promise.resolve(null);
  var hls = stream.type === 'hls' || /\.m3u8(?:[?#]|$)/i.test(stream.url);
  var dash = stream.type === 'dash' || /\.mpd(?:[?#]|$)/i.test(stream.url);
  if (stream.sourceName === 'KinoPub' && !/^https:\/\//i.test(stream.url)) return Promise.resolve(null);
  // Fetching KinoPub playlists starts paid account sessions. Use its selected
  // media-link API response and resolution/codec metadata until actual playback.
  if (stream.sourceName === 'KinoPub' && stream.metadataVerified === true && /^https:\/\//i.test(stream.url) && /^(?:hls|dash|mp4)$/.test(stream.type || '') && /^\d{3,4}p$/.test(stream.quality || '')) return Promise.resolve(stream);
  var headers = {};
  headers = playbackHeaders(stream.headers);
  // Nuvio TV's native bridge maps HEAD to GET. A small byte range avoids
  // requesting the video body while checking that an MP4 URL is still usable.
  if (!hls && !dash) headers.Range = 'bytes=0-63';
  var opts = { session: http.session(cfg.deadline), headers: headers, responseInfo: true, method: 'GET', binary: !hls && !dash };
  return http.request(stream.url, opts).then(function (response) {
    if (hls || dash) {
      var details = dash ? media.dash(response.body) : media.hls(response.body);
      if (!details) return null;
      if (details.quality) stream.quality = details.quality;
      if (details.codecSummary) stream.codecSummary = details.codecSummary;
    } else {
      var range = /^bytes\s+0-(\d+)\/(\d+)$/i.exec(response.contentRange);
      var data = response.data || [];
      if (response.status !== 206 || !range || Number(range[1]) + 1 !== data.length || Number(range[2]) <= data.length || data.length < 16 || data.length > 64) return null;
      if (!/^(?:video\/|application\/(?:octet-stream|mp4))/i.test(response.contentType) || String.fromCharCode.apply(null, data.slice(4, 8)) !== 'ftyp') return null;
    }
    stream.type = dash ? 'dash' : hls ? 'hls' : 'mp4';
    return stream;
  }).catch(function () { return null; });
}

function getStreams(tmdbId, mediaType, season, episode) {
  var type = ['tv', 'series', 'show'].indexOf(mediaType) !== -1 ? 'tv' : mediaType;
  if (!/^\d+$/.test(String(tmdbId)) || ['movie', 'tv'].indexOf(type) === -1) return Promise.resolve([]);
  if (type === 'tv' && (!/^\d+$/.test(String(season)) || !/^\d+$/.test(String(episode)) || Number(season) < 0 || Number(episode) < 1)) return Promise.resolve([]);
  if (type === 'tv') { season = Number(season); episode = Number(episode); }
  var cfg = settings();
  return metadata(String(tmdbId), type, cfg).then(function (meta) {
    return Promise.all([
      source('Filmix', filmix, meta, season, episode, cfg),
      type === 'tv' ? source('Seasonvar', seasonvar, meta, season, episode, cfg) : Promise.resolve([]),
      source('Collaps', collaps, meta, season, episode, cfg),
      cfg.kinopubToken ? source('KinoPub', kinopub, meta, season, episode, cfg) : Promise.resolve([]),
      cfg.hdvbToken ? source('HDVB', hdvb, meta, season, episode, cfg) : Promise.resolve([])
    ]).then(function (results) {
      var seen = {};
      var all = [];
      results.forEach(function (list) { all = all.concat(list); });
      var candidates = all.filter(function (stream) {
        if (!stream || !stream.url || seen[stream.url]) return false;
        seen[stream.url] = true; return true;
      });
      return Promise.all(candidates.map(function (stream) { return verify(stream, cfg); }));
    }).then(function (streams) {
      return streams.filter(Boolean).map(function (stream) {
        var headers = playbackHeaders(stream.headers);
        var subtitles = (stream.subtitles || []).filter(function (sub) { return /^https?:\/\//i.test(String(sub.url || '')); }).map(function (sub, index) {
          return { id: sub.id || 'russian-cinema-' + index, url: sub.url, language: sub.language || sub.lang || 'ru', name: sub.name || sub.label || sub.language || 'Subtitle', headers: sub.headers ? playbackHeaders(sub.headers) : headers };
        });
        return {
          name: 'Russian Cinema', provider: 'Russian Cinema',
          title: meta.title + (type === 'tv' ? ' S' + season + 'E' + episode : '') + ' | ' + stream.sourceName + (stream.title ? ' | ' + String(stream.title).replace(/^(?:Filmix|Seasonvar|Collaps|KinoPub|HDVB)\s*[|·]\s*/i, '') : '') + (stream.codecSummary ? ' | ' + stream.codecSummary : ''),
          url: stream.url, quality: stream.quality || 'Auto', type: stream.type, headers: headers, subtitles: subtitles
        };
      });
    });
  }).catch(function (error) {
    console.warn('[Russian Cinema] ' + (error && error.providerSafe ? error.message : !cfg.key ? 'TMDB key unavailable. Enter your own key in Russian Cinema settings.' : 'Metadata lookup failed.'));
    return [];
  });
}

function onSettings() {
  return Promise.resolve([
    { type: 'header', label: 'Russian Cinema' },
    { type: 'text', key: 'seasonvarSite', label: 'Seasonvar website', defaultValue: DEFAULT_SEASONVAR, description: 'Update this HTTPS origin if Seasonvar moves.' },
    { type: 'text', key: 'collapsSite', label: 'Collaps player', defaultValue: DEFAULT_COLLAPS, description: 'Public movie and episode player. Includes 1080p DASH when available.' },
    { type: 'text', key: 'kinopubToken', label: 'KinoPub access token (optional)', isPassword: true, defaultValue: '', description: 'Your own authorized account access token. Leave empty to skip KinoPub.' },
    { type: 'text', key: 'kinopubApi', label: 'KinoPub API', defaultValue: DEFAULT_KINOPUB, description: 'HTTPS API origin for your KinoPub account.' },
    { type: 'text', key: 'hdvbToken', label: 'HDVB partner API key (optional)', isPassword: true, defaultValue: '', description: 'Your own approved partner key. Leave empty to skip HDVB.' },
    { type: 'text', key: 'hdvbApi', label: 'HDVB API', defaultValue: DEFAULT_HDVB, description: 'HTTPS origin for approved HDVB API access.' },
    { type: 'text', key: 'tmdbApiKey', label: 'TMDB API key (optional)', isPassword: true, defaultValue: '', description: 'Uses Nuvio\'s key when available. Otherwise enter your own v3 key or API Read Access Token.' }
  ]);
}

module.exports = { getStreams: getStreams, onSettings: onSettings };
