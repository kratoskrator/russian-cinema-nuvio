'use strict';
var u = require('./utils');
var http = require('./http');
var filmix = require('./filmix');
var seasonvar = require('./seasonvar');
var DEFAULT_SEASONVAR = 'https://seasonvar.ru';

function settings() {
  var root = typeof globalThis !== 'undefined' ? globalThis : {};
  var saved = root.SCRAPER_SETTINGS || {};
  return {
    seasonvarSite: u.siteUrl(saved.seasonvarSite || DEFAULT_SEASONVAR) || DEFAULT_SEASONVAR,
    key: String(saved.tmdbApiKey || root.TMDB_API_KEY || '').trim(),
    deadline: Date.now() + 50000
  };
}

function metadata(id, type, cfg) {
  if (!cfg.key) return Promise.reject(new Error('TMDB key unavailable. Enter your own key in Russian Cinema settings.'));
  var token = cfg.key.length > 40;
  var url = 'https://api.themoviedb.org/3/' + type + '/' + encodeURIComponent(id) + '?language=ru-RU&append_to_response=external_ids';
  if (!token) url += '&api_key=' + encodeURIComponent(cfg.key);
  return http.request(url, { json: true, bearer: token ? cfg.key : '', session: http.session(cfg.deadline) }).then(function (data) {
    var imdb = data.external_ids && data.external_ids.imdb_id || data.imdb_id || '';
    return {
      type: type, title: data.title || data.name || '', originalTitle: data.original_title || data.original_name || '',
      year: Number(String(data.release_date || data.first_air_date || '').slice(0, 4)) || null,
      imdb: /^tt\d{7,10}$/.test(imdb) ? imdb : ''
    };
  });
}

function client(cfg) {
  var state = http.session(cfg.deadline);
  return { request: function (url, options) {
    options = options || {};
    options.session = state;
    return http.request(url, options);
  } };
}

function source(label, module, meta, season, episode, cfg) {
  return Promise.resolve().then(function () {
    return module.resolve(meta, season, episode, cfg, client(cfg));
  }).then(function (streams) {
    return (Array.isArray(streams) ? streams : []).slice(0, 8).map(function (stream) { stream.sourceName = label; return stream; });
  }).catch(function (error) {
    console.warn('[Russian Cinema / ' + label + '] ' + (error && error.providerSafe ? error.message : 'Source resolution failed.'));
    return [];
  });
}

function verify(stream, cfg) {
  if (!stream || !/^https?:\/\/[^\s/?#@]+(?:[/?#][^\s]*)?$/i.test(String(stream.url || ''))) return Promise.resolve(null);
  var hls = stream.type === 'hls' || /\.m3u8(?:[?#]|$)/i.test(stream.url);
  var headers = {};
  Object.keys(stream.headers || {}).forEach(function (name) { headers[name] = stream.headers[name]; });
  // Nuvio TV's native bridge maps HEAD to GET. A small byte range avoids
  // requesting the video body while checking that an MP4 URL is still usable.
  if (!hls) headers.Range = 'bytes=0-63';
  var opts = { session: http.session(cfg.deadline), headers: headers, responseInfo: true, method: 'GET', binary: !hls };
  return http.request(stream.url, opts).then(function (response) {
    if (hls) {
      if (!/^\s*#EXTM3U/.test(response.body)) return null;
    } else {
      var range = /^bytes\s+0-(\d+)\/(\d+)$/i.exec(response.contentRange);
      var data = response.data || [];
      if (response.status !== 206 || !range || Number(range[1]) + 1 !== data.length || Number(range[2]) <= data.length || data.length < 16 || data.length > 64) return null;
      if (!/^(?:video\/|application\/(?:octet-stream|mp4))/i.test(response.contentType) || String.fromCharCode.apply(null, data.slice(4, 8)) !== 'ftyp') return null;
    }
    stream.type = hls ? 'hls' : 'mp4';
    return stream;
  }).catch(function () { return null; });
}

function getStreams(tmdbId, mediaType, season, episode) {
  var type = ['tv', 'series', 'show'].indexOf(mediaType) !== -1 ? 'tv' : mediaType;
  if (!/^\d+$/.test(String(tmdbId)) || ['movie', 'tv'].indexOf(type) === -1) return Promise.resolve([]);
  if (type === 'tv' && (!/^\d+$/.test(String(season)) || !/^\d+$/.test(String(episode)) || Number(season) < 0 || Number(episode) < 1)) return Promise.resolve([]);
  if (type === 'tv') { season = Number(season); episode = Number(episode); }
  var cfg = settings();
  return metadata(String(tmdbId), type, cfg).then(function (meta) {
    return Promise.all([
      source('Filmix', filmix, meta, season, episode, cfg),
      type === 'tv' ? source('Seasonvar', seasonvar, meta, season, episode, cfg) : Promise.resolve([])
    ]).then(function (results) {
      var seen = {};
      var candidates = results[0].concat(results[1]).filter(function (stream) {
        if (!stream || !stream.url || seen[stream.url]) return false;
        seen[stream.url] = true; return true;
      });
      return Promise.all(candidates.map(function (stream) { return verify(stream, cfg); }));
    }).then(function (streams) {
      return streams.filter(Boolean).map(function (stream) {
        var headers = stream.headers || {};
        var subtitles = (stream.subtitles || []).filter(function (sub) { return /^https?:\/\//i.test(String(sub.url || '')); }).map(function (sub, index) {
          return { id: sub.id || 'russian-cinema-' + index, url: sub.url, language: sub.language || sub.lang || 'ru', name: sub.name || sub.label || sub.language || 'Subtitle', headers: sub.headers || headers };
        });
        return {
          name: 'Russian Cinema', provider: 'Russian Cinema',
          title: meta.title + (type === 'tv' ? ' S' + season + 'E' + episode : '') + ' | ' + stream.sourceName + (stream.title ? ' | ' + String(stream.title).replace(/^(?:Filmix|Seasonvar)\s*[|·]\s*/i, '') : ''),
          url: stream.url, quality: stream.quality || 'Auto', type: stream.type, headers: headers, subtitles: subtitles
        };
      });
    });
  }).catch(function (error) {
    console.warn('[Russian Cinema] ' + (error && error.providerSafe ? error.message : !cfg.key ? 'TMDB key unavailable. Enter your own key in Russian Cinema settings.' : 'Metadata lookup failed.'));
    return [];
  });
}

function onSettings() {
  return Promise.resolve([
    { type: 'header', label: 'Russian Cinema' },
    { type: 'text', key: 'seasonvarSite', label: 'Seasonvar website', defaultValue: DEFAULT_SEASONVAR, description: 'Update this HTTPS origin if Seasonvar moves.' },
    { type: 'text', key: 'tmdbApiKey', label: 'TMDB API key (optional)', isPassword: true, defaultValue: '', description: 'Uses Nuvio\'s key when available. Otherwise enter your own v3 key or API Read Access Token.' }
  ]);
}

module.exports = { getStreams: getStreams, onSettings: onSettings };
