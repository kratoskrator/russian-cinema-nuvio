'use strict';
var u = require('./utils');
var media = require('./media');

// Filmix publishes this mobile API over HTTP. Guest requests contain no account
// token, password, cookies, or TMDB key. Optional account HLS uses the separate
// fixed HTTPS FilmixTV API below; its bearer token never enters the guest path.
var API = 'http://filmixapp.cyou/api/v2';
var USER_AGENT = 'okhttp/4.9.2';
var MAX_STREAMS = 8;
var GUEST_QUALITY = 480;
var TV_API = 'https://api.filmix.tv/api-fx';
var MAX_ACCOUNT_STREAMS = 2;
// Higher resolutions listed in a guest response can resolve to short preview
// files. Do not infer an account entitlement from a filename or quality list.
// The published mobile API mirrors currently lack a verified HTTPS endpoint;
// the distinct FilmixTV protocol cannot use their mobile device tokens.
var ACCOUNT_UNAVAILABLE = 'Mobile Pro / Pro+ tokens need a verified HTTPS mobile API. FilmixTV account mode also needs safe redirect handling unavailable in this Nuvio runtime. Guest access is limited to 480p.';
var TV_RUNTIME_UNAVAILABLE = 'FilmixTV account mode is unavailable in this Nuvio runtime: redirects can forward its device hash. Guest sources remain available.';

function safeError(message) {
  var error = new Error('Filmix: ' + message);
  error.providerSafe = true;
  return error;
}

function deviceId() {
  var value = '';
  for (var i = 0; i < 16; i++) value += Math.floor(Math.random() * 16).toString(16);
  return value;
}

function apiUrl(path, id, values) {
  var params = {
    user_dev_id: id,
    user_dev_name: 'Russian Cinema',
    user_dev_vendor: 'Samsung',
    user_dev_os: 'Tizen',
    user_dev_apk: '2.0.9'
  };
  Object.keys(values || {}).forEach(function (name) { params[name] = values[name]; });
  return API + '/' + path + '?' + u.form(params);
}

function isSeries(item) {
  return Number(item.section) === 7 || !!(item.serial_stats && !Array.isArray(item.serial_stats)) ||
    !!(item.last_episode && item.last_episode.post_id);
}

function imdbId(item) {
  var value = String(item.imdb_id || item.imdb || '');
  return /^tt\d{7,10}$/.test(value) ? value : '';
}

function matchScore(item, meta) {
  if (!item || !/^\d+$/.test(String(item.id || ''))) return -1;
  if (isSeries(item) !== (meta.type === 'tv')) return -1;
  var wanted = [u.normalize(meta.title), u.normalize(meta.originalTitle)].filter(Boolean);
  var names = [u.normalize(item.title), u.normalize(item.original_title)].filter(Boolean);
  var exactImdb = !!(meta.imdb && imdbId(item) === meta.imdb);
  var exactTitle = wanted.some(function (title) { return names.indexOf(title) !== -1; });
  if (!exactImdb && !exactTitle) return -1;
  var year = Number(item.year) || 0;
  var distance = meta.year && year ? Math.abs(Number(meta.year) - year) : null;
  // An IMDb match identifies the work; title-only remakes must agree on year.
  if (!exactImdb && distance !== null && distance > 1) return -1;
  return (exactImdb ? 200 : 100) + (distance === 0 ? 20 : distance === 1 ? 5 : 0);
}

function selectResult(results, meta) {
  if (!Array.isArray(results)) return null;
  var best = null, score = -1;
  results.slice(0, 100).forEach(function (item) {
    var next = matchScore(item, meta);
    if (next > score) { best = item; score = next; }
  });
  return best;
}

function search(meta, id, client) {
  var queries = [meta.originalTitle, meta.title].filter(function (query, index, all) {
    return query && all.indexOf(query) === index;
  }).slice(0, 2);
  function next(index) {
    if (index >= queries.length) return Promise.resolve(null);
    return client.request(apiUrl('search', id, { story: queries[index] }), {
      json: true, headers: { 'User-Agent': USER_AGENT }, timeout: 10000
    }).then(function (results) {
      return selectResult(results, meta) || next(index + 1);
    });
  }
  return next(0);
}

function qualities(link, declared) {
  var bracket = /\[([\d,]+)\]/.exec(link);
  var list = Array.isArray(declared) ? declared : bracket ? bracket[1].split(',') : [];
  var unique = {};
  return list.map(Number).filter(function (value) {
    if (value <= 0 || value > GUEST_QUALITY || unique[value]) return false;
    unique[value] = true;
    return true;
  }).sort(function (a, b) { return b - a; });
}

function mediaLink(link, declared) {
  if (typeof link !== 'string' || link.length > 8192 || /[\s\x00-\x1f\x7f]/.test(link)) return null;
  var available = qualities(link, declared), quality = available[0];
  var hasPlaceholder = /\[[\d,]+\]|%s/.test(link);
  if (hasPlaceholder) {
    if (!quality) return null;
    link = link.replace(/\[[\d,]+\]/g, String(quality)).replace(/%s/g, String(quality));
  } else {
    var namedQuality = /(?:_|[.\/-])(\d{3,4})(?:p)?\.(?:mp4|m3u8)(?:[?#]|$)/i.exec(link);
    if (namedQuality) quality = Number(namedQuality[1]);
    // Do not mislabel an unknown or premium stream as an unrestricted guest file.
    if (!quality || quality > GUEST_QUALITY) return null;
  }
  if (!/^https?:\/\/[^\s/?#@]+\/[^\s]*\.(?:mp4|m3u8)(?:[?#][^\s]*)?$/i.test(link)) return null;
  return { url: link, quality: quality + 'p', type: /\.m3u8(?:[?#]|$)/i.test(link) ? 'hls' : 'mp4' };
}

function candidates(post, meta, season, episode) {
  var links = post && post.player_links;
  if (!links || typeof links !== 'object') return [];
  var selected = [];
  if (meta.type === 'movie') {
    if (!Array.isArray(links.movie)) return [];
    selected = links.movie.slice(0, 24).map(function (entry) {
      return { entry: entry, voice: entry.translation || 'Russian voiceover' };
    });
  } else {
    var seasons = links.playlist;
    var translations = seasons && !Array.isArray(seasons) && seasons[String(Number(season))];
    if (!translations || typeof translations !== 'object' || Array.isArray(translations)) return [];
    Object.keys(translations).slice(0, 24).forEach(function (voice) {
      var episodes = translations[voice];
      var entry = Array.isArray(episodes) ? episodes[Number(episode) - 1] : episodes && episodes[String(Number(episode))];
      if (entry) selected.push({ entry: entry, voice: voice });
    });
  }
  var seen = {};
  return selected.map(function (item) {
    var entry = item.entry;
    if (!entry || typeof entry !== 'object') return null;
    var media = mediaLink(entry.link, entry.qualities);
    if (!media || seen[media.url]) return null;
    seen[media.url] = true;
    media.title = 'Filmix | ' + u.text(item.voice).slice(0, 160) + ' | Guest';
    media.headers = { 'User-Agent': USER_AGENT, Accept: '*/*' };
    return media;
  }).filter(Boolean).slice(0, MAX_STREAMS);
}

function guestResolve(meta, season, episode, client) {
  var id = deviceId();
  return search(meta, id, client).then(function (result) {
    if (!result) return [];
    return client.request(apiUrl('post/' + result.id, id), {
      json: true, headers: { 'User-Agent': USER_AGENT }, timeout: 10000
    }).then(function (post) {
      if (!post || Number(post.id) !== Number(result.id)) return [];
      // Recheck the returned metadata instead of trusting a stale search result.
      if (matchScore(post, meta) < 0) return [];
      return candidates(post, meta, season, episode);
    });
  });
}

function tvItem(item) {
  if (!item || typeof item !== 'object') return null;
  var serial = Number(item.last_season) > 0 || Number(item.last_episode) > 0 || /\/seria\//i.test(String(item.url || ''));
  return {
    id: item.id, title: item.title, original_title: item.original_name || item.original_title,
    year: item.year, section: serial ? 7 : 0, imdb_id: item.imdb_id
  };
}

function tvApi(path, cfg, client) {
  return client.request(TV_API + path, {
    json: true, responseInfo: true, timeout: 10000, bearer: cfg.filmixTvToken, redirect: 'error',
    headers: { 'User-Agent': USER_AGENT, hash: cfg.filmixTvHash }
  }).then(function (response) {
    if (!response || !u.sameSite(response.finalUrl || '', TV_API)) throw safeError('FilmixTV account API response could not be verified.');
    return response.body;
  });
}

function tvSearch(meta, cfg, client) {
  var queries = [meta.originalTitle, meta.title].filter(function (value, index, all) { return value && all.indexOf(value) === index; }).slice(0, 2);
  function next(index) {
    if (index >= queries.length) return Promise.resolve(null);
    return tvApi('/list?search=' + encodeURIComponent(queries[index]) + '&limit=48', cfg, client).then(function (data) {
      var items = data && Array.isArray(data.items) ? data.items.slice(0, 100).map(tvItem).filter(Boolean) : [];
      return selectResult(items, meta) || next(index + 1);
    });
  }
  return next(0);
}

function hlsUrl(value, base) {
  var url = u.absolute(String(value || ''), base || TV_API);
  if (url.length > 8192 || !/^https:\/\/[^\s/?#@]+\/[^\s]*\.m3u8(?:[?#][^\s]*)?$/i.test(url) || u.sameSite(url, TV_API)) return '';
  return url;
}

function accountUrlSafe(url, account) {
  var decoded = String(url || '');
  try { decoded = decodeURIComponent(decoded); } catch (ignored) { return false; }
  var secrets = [account && account.filmixTvToken, account && account.filmixTvHash].filter(Boolean);
  if (secrets.some(function (secret) { return decoded.indexOf(secret) !== -1; })) return false;
  return !/[?&#](?:token|access_token|refresh_token|user_dev_token|api_key|apikey|authorization|auth|bearer|hash|device_hash|password|user_passw|passw)=/i.test(decoded);
}

function tvCandidates(data, meta, season, episode) {
  var voices = [];
  if (meta.type === 'movie') {
    if (!Array.isArray(data)) return [];
    data.slice(0, 24).forEach(function (voice) { voices.push({ name: voice.voiceover, files: voice.files }); });
  } else {
    if (!data || typeof data !== 'object' || Array.isArray(data)) return [];
    Object.keys(data).slice(0, 24).forEach(function (name) {
      var seasons = data[name];
      if (!seasons || typeof seasons !== 'object' || Array.isArray(seasons)) return;
      Object.keys(seasons).slice(0, 100).forEach(function (key) {
        var value = seasons[key];
        if (!value || Number(value.season) !== Number(season) || !value.episodes || typeof value.episodes !== 'object') return;
        var selected = value.episodes['e' + Number(episode)] || value.episodes[String(Number(episode))];
        if (selected && Number(selected.episode) === Number(episode)) voices.push({ name: name, files: selected.files });
      });
    });
  }
  var out = [], seen = {};
  voices.forEach(function (voice) {
    if (!Array.isArray(voice.files)) return;
    voice.files.slice(0, 16).forEach(function (file) {
      var quality = Number(file && file.quality), url = hlsUrl(file && file.url);
      // MP4 filenames can return a premium preview. Account mode deliberately
      // supports only HLS whose complete duration can be checked without video.
      if (!url || quality < 1080 || quality > 2160 || seen[url]) return;
      seen[url] = true;
      out.push({ url: url, quality: quality, voice: u.text(voice.name).slice(0, 160) || 'Russian voiceover' });
    });
  });
  out.sort(function (a, b) { return b.quality - a.quality; });
  var selected = [];
  if (out.length) {
    selected.push(out[0]);
    var fallback = out.filter(function (item) { return item.quality !== out[0].quality; })[0] || out[1];
    if (fallback) selected.push(fallback);
  }
  return selected.slice(0, MAX_ACCOUNT_STREAMS);
}

function vodDuration(body, expected) {
  if (typeof body !== 'string' || !/^\s*#EXTM3U/.test(body) || !/#EXT-X-ENDLIST(?:\s|$)/.test(body) || /#EXT-X-STREAM-INF|#EXT-X-I-FRAME-STREAM-INF/.test(body)) return 0;
  var lines = body.split(/\r?\n/), duration = 0, segments = 0, pending = false;
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].trim(), value = /^#EXTINF:(\d+(?:\.\d+)?)(?:,|$)/.exec(line);
    if (value) {
      if (pending || Number(value[1]) <= 0 || Number(value[1]) > 600) return 0;
      duration += Number(value[1]); pending = true;
    } else if (line && line.charAt(0) !== '#') {
      if (!pending || /^(?!https:\/\/)[\w+.-]+:|^\/\//i.test(line)) return 0;
      pending = false; segments++;
    }
  }
  if (pending || !segments || segments > 15000 || !isFinite(duration) || duration < expected * 0.8 || duration > expected * 1.25) return 0;
  return duration;
}

function tvPlaylist(candidate, expected, client, account) {
  var playbackHeaders = { 'User-Agent': USER_AGENT, Accept: '*/*' };
  function read(url) {
    // Account Authorization and device hash belong only to the API host.
    if (!accountUrlSafe(url, account)) return Promise.reject(safeError('FilmixTV media URL contains account credentials.'));
    return client.request(url, { responseInfo: true, headers: playbackHeaders, timeout: 10000 }).then(function (response) {
      if (!response || !/^https:\/\//i.test(response.finalUrl || '') || !accountUrlSafe(response.finalUrl, account)) throw safeError('FilmixTV HLS response could not be verified.');
      return { body: response.body, url: response.finalUrl };
    });
  }
  return read(candidate.url).then(function (response) {
    var body = response.body, url = response.url, quality = candidate.quality, actual = false;
    var lines = typeof body === 'string' ? body.split(/\r?\n/) : [], variants = [];
    for (var i = 0; i < lines.length; i++) {
      var tag = /^#EXT-X-STREAM-INF:(.*)/.exec(lines[i].trim());
      if (!tag) continue;
      var resolution = /(?:^|,)\s*RESOLUTION=\d+x(\d+)(?:,|$)/i.exec(tag[1]);
      var next = i + 1;
      while (next < lines.length && !lines[next].trim()) next++;
      var variantUrl = next < lines.length ? hlsUrl(lines[next].trim(), url) : '';
      if (resolution && variantUrl && accountUrlSafe(variantUrl, account) && Number(resolution[1]) >= 1080 && Number(resolution[1]) <= Math.min(candidate.quality, 2160)) {
        variants.push({ url: variantUrl, quality: Number(resolution[1]) });
      }
    }
    variants.sort(function (a, b) { return b.quality - a.quality; });
    var chosen = variants[0];
    if (/#EXT-X-STREAM-INF/.test(String(body)) && !chosen) return null;
    var selectedPlaylist = chosen ? read(chosen.url) : Promise.resolve(response);
    if (chosen) { quality = chosen.quality; actual = true; }
    return selectedPlaylist.then(function (playlist) {
      var duration = media.hls(playlist.body) ? vodDuration(playlist.body, expected) : 0;
      if (!duration) return null;
      return {
        url: playlist.url, quality: quality + 'p', type: 'hls', headers: playbackHeaders,
        title: 'FilmixTV | ' + candidate.voice + ' | Account' + (actual ? '' : ' | source-labelled ' + quality + 'p'),
        qualityVerified: actual, qualitySource: actual ? 'hls' : 'api', durationVerified: true, durationSeconds: duration
      };
    });
  });
}

function tvResolve(meta, season, episode, cfg, client) {
  // Nuvio TV's current bridge ignores fetch redirect options and forwards
  // custom headers on cross-origin redirects. A finalUrl check is too late to
  // protect the device hash. Only a host client that enforces redirect:'error'
  // (or strips this credential before redirects) may enable this adapter.
  // This is an internal host capability, never a user-configurable setting.
  if (!client || client.filmixTvRedirectSafe !== true) return Promise.reject(safeError(TV_RUNTIME_UNAVAILABLE));
  var token = String(cfg.filmixTvToken || '').trim(), hash = String(cfg.filmixTvHash || '').trim();
  var expected = Number(meta.runtimeSeconds);
  if (!/^[A-Za-z0-9._~-]{8,4096}$/.test(token) || !/^[A-Za-z0-9_-]{16,128}$/.test(hash)) return Promise.reject(safeError('FilmixTV needs your own access token and matching device hash.'));
  if (!isFinite(expected) || expected < 60 || expected > 40000) return Promise.reject(safeError('FilmixTV needs an exact title or episode runtime to reject preview streams.'));
  var account = { filmixTvToken: token, filmixTvHash: hash };
  return tvSearch(meta, account, client).then(function (result) {
    if (!result) return [];
    return tvApi('/post/' + result.id + '/video-links', account, client).then(function (data) {
      return Promise.all(tvCandidates(data, meta, season, episode).map(function (candidate) {
        return tvPlaylist(candidate, expected, client, account).catch(function () { return null; });
      })).then(function (streams) { return streams.filter(Boolean); });
    });
  });
}

function resolve(meta, season, episode, cfg, client) {
  if (!meta || ['movie', 'tv'].indexOf(meta.type) === -1) return Promise.resolve([]);
  if (meta.type === 'tv' && (!/^\d+$/.test(String(season)) || !/^\d+$/.test(String(episode)) || Number(episode) < 1)) return Promise.resolve([]);
  cfg = cfg || {};
  // The mobile token is not interchangeable with a FilmixTV bearer token.
  if (cfg.filmixToken || cfg.filmixUsername || cfg.filmixPassword || cfg.filmixApi) return Promise.reject(safeError(ACCOUNT_UNAVAILABLE));
  var guest = guestResolve(meta, season, episode, client);
  if (!cfg.filmixTvToken && !cfg.filmixTvHash) return guest;
  guest = guest.catch(function () { return []; });
  var account = tvResolve(meta, season, episode, cfg, client).catch(function (error) {
    console.warn('[Russian Cinema / FilmixTV] ' + (error && error.providerSafe && error.message === 'Filmix: ' + TV_RUNTIME_UNAVAILABLE ? TV_RUNTIME_UNAVAILABLE : 'Account HLS could not be verified. Guest sources remain available.'));
    return [];
  });
  return Promise.all([account, guest]).then(function (results) { return results[0].concat(results[1]).slice(0, MAX_STREAMS); });
}

module.exports = {
  resolve: resolve, matchScore: matchScore, selectResult: selectResult,
  mediaLink: mediaLink, candidates: candidates, tvCandidates: tvCandidates, vodDuration: vodDuration,
  capabilities: { guestMaxQuality: GUEST_QUALITY, accountAvailable: false, accountImplemented: true, accountType: 'FilmixTV HLS with runtime verification', accountMessage: TV_RUNTIME_UNAVAILABLE }
};
