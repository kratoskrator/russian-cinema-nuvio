'use strict';
var u = require('./utils');

// Filmix publishes this mobile API over HTTP. Guest requests contain no account
// token, password, cookies, or TMDB key. Paid/account streams are not requested.
var API = 'http://filmixapp.cyou/api/v2';
var USER_AGENT = 'okhttp/4.9.2';
var MAX_STREAMS = 8;
var GUEST_QUALITY = 480;

function safeError(message) {
  var error = new Error('Filmix: ' + message);
  error.providerSafe = true;
  return error;
}

function deviceId() {
  var value = '';
  for (var i = 0; i < 16; i++) value += Math.floor(Math.random() * 16).toString(16);
  return value;
}

function apiUrl(path, id, values) {
  var params = {
    user_dev_id: id,
    user_dev_name: 'Russian Cinema',
    user_dev_vendor: 'Samsung',
    user_dev_os: 'Tizen',
    user_dev_apk: '2.0.9'
  };
  Object.keys(values || {}).forEach(function (name) { params[name] = values[name]; });
  return API + '/' + path + '?' + u.form(params);
}

function isSeries(item) {
  return Number(item.section) === 7 || !!(item.serial_stats && !Array.isArray(item.serial_stats)) ||
    !!(item.last_episode && item.last_episode.post_id);
}

function imdbId(item) {
  var value = String(item.imdb_id || item.imdb || '');
  return /^tt\d{7,10}$/.test(value) ? value : '';
}

function matchScore(item, meta) {
  if (!item || !/^\d+$/.test(String(item.id || ''))) return -1;
  if (isSeries(item) !== (meta.type === 'tv')) return -1;
  var wanted = [u.normalize(meta.title), u.normalize(meta.originalTitle)].filter(Boolean);
  var names = [u.normalize(item.title), u.normalize(item.original_title)].filter(Boolean);
  var exactImdb = !!(meta.imdb && imdbId(item) === meta.imdb);
  var exactTitle = wanted.some(function (title) { return names.indexOf(title) !== -1; });
  if (!exactImdb && !exactTitle) return -1;
  var year = Number(item.year) || 0;
  var distance = meta.year && year ? Math.abs(Number(meta.year) - year) : null;
  // An IMDb match identifies the work; title-only remakes must agree on year.
  if (!exactImdb && distance !== null && distance > 1) return -1;
  return (exactImdb ? 200 : 100) + (distance === 0 ? 20 : distance === 1 ? 5 : 0);
}

function selectResult(results, meta) {
  if (!Array.isArray(results)) return null;
  var best = null, score = -1;
  results.slice(0, 100).forEach(function (item) {
    var next = matchScore(item, meta);
    if (next > score) { best = item; score = next; }
  });
  return best;
}

function search(meta, id, client) {
  var queries = [meta.originalTitle, meta.title].filter(function (query, index, all) {
    return query && all.indexOf(query) === index;
  }).slice(0, 2);
  function next(index) {
    if (index >= queries.length) return Promise.resolve(null);
    return client.request(apiUrl('search', id, { story: queries[index] }), {
      json: true, headers: { 'User-Agent': USER_AGENT }, timeout: 10000
    }).then(function (results) {
      return selectResult(results, meta) || next(index + 1);
    });
  }
  return next(0);
}

function qualities(link, declared) {
  var bracket = /\[([\d,]+)\]/.exec(link);
  var list = Array.isArray(declared) ? declared : bracket ? bracket[1].split(',') : [];
  var unique = {};
  return list.map(Number).filter(function (value) {
    if (value <= 0 || value > GUEST_QUALITY || unique[value]) return false;
    unique[value] = true;
    return true;
  }).sort(function (a, b) { return b - a; });
}

function mediaLink(link, declared) {
  if (typeof link !== 'string' || link.length > 8192 || /[\s\x00-\x1f\x7f]/.test(link)) return null;
  var available = qualities(link, declared), quality = available[0];
  var hasPlaceholder = /\[[\d,]+\]|%s/.test(link);
  if (hasPlaceholder) {
    if (!quality) return null;
    link = link.replace(/\[[\d,]+\]/g, String(quality)).replace(/%s/g, String(quality));
  } else {
    var namedQuality = /(?:_|[.\/-])(\d{3,4})(?:p)?\.(?:mp4|m3u8)(?:[?#]|$)/i.exec(link);
    if (namedQuality) quality = Number(namedQuality[1]);
    // Do not mislabel an unknown or premium stream as an unrestricted guest file.
    if (!quality || quality > GUEST_QUALITY) return null;
  }
  if (!/^https?:\/\/[^\s/?#@]+\/[^\s]*\.(?:mp4|m3u8)(?:[?#][^\s]*)?$/i.test(link)) return null;
  return { url: link, quality: quality + 'p', type: /\.m3u8(?:[?#]|$)/i.test(link) ? 'hls' : 'mp4' };
}

function candidates(post, meta, season, episode) {
  var links = post && post.player_links;
  if (!links || typeof links !== 'object') return [];
  var selected = [];
  if (meta.type === 'movie') {
    if (!Array.isArray(links.movie)) return [];
    selected = links.movie.slice(0, 24).map(function (entry) {
      return { entry: entry, voice: entry.translation || 'Russian voiceover' };
    });
  } else {
    var seasons = links.playlist;
    var translations = seasons && !Array.isArray(seasons) && seasons[String(Number(season))];
    if (!translations || typeof translations !== 'object' || Array.isArray(translations)) return [];
    Object.keys(translations).slice(0, 24).forEach(function (voice) {
      var episodes = translations[voice];
      var entry = Array.isArray(episodes) ? episodes[Number(episode) - 1] : episodes && episodes[String(Number(episode))];
      if (entry) selected.push({ entry: entry, voice: voice });
    });
  }
  var seen = {};
  return selected.map(function (item) {
    var entry = item.entry;
    if (!entry || typeof entry !== 'object') return null;
    var media = mediaLink(entry.link, entry.qualities);
    if (!media || seen[media.url]) return null;
    seen[media.url] = true;
    media.title = 'Filmix | ' + u.text(item.voice).slice(0, 160) + ' | Guest';
    media.headers = { 'User-Agent': USER_AGENT, Accept: '*/*' };
    return media;
  }).filter(Boolean).slice(0, MAX_STREAMS);
}

function resolve(meta, season, episode, cfg, client) {
  if (!meta || ['movie', 'tv'].indexOf(meta.type) === -1) return Promise.resolve([]);
  if (meta.type === 'tv' && (!/^\d+$/.test(String(season)) || !/^\d+$/.test(String(episode)) || Number(episode) < 1)) return Promise.resolve([]);
  // Never downgrade account credentials to this unencrypted public guest API.
  if (cfg && cfg.filmixToken) return Promise.reject(safeError('Account tokens are unavailable on the public guest API.'));
  var id = deviceId();
  return search(meta, id, client).then(function (result) {
    if (!result) return [];
    return client.request(apiUrl('post/' + result.id, id), {
      json: true, headers: { 'User-Agent': USER_AGENT }, timeout: 10000
    }).then(function (post) {
      if (!post || Number(post.id) !== Number(result.id)) return [];
      // Recheck the returned metadata instead of trusting a stale search result.
      if (matchScore(post, meta) < 0) return [];
      return candidates(post, meta, season, episode);
    });
  });
}

module.exports = { resolve: resolve, matchScore: matchScore, selectResult: selectResult, mediaLink: mediaLink, candidates: candidates };
