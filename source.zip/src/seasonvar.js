'use strict';
var u = require('./utils');

// Parse only published page data. No script from Seasonvar is executed.
function cleanHtml(html) { return String(html || '').replace(/<!--[\s\S]*?-->/g, ''); }
function titleKey(value) {
  return u.normalize(u.text(value).replace(/^\s*(?:Сериал|Сериалы)\s+/i, '').replace(/\s+\d+\s*сезон(?:\s|$).*$/i, '').replace(/\s+онлайн\s*$/i, ''));
}
function metaKeys(meta) {
  var keys = [];
  [meta.originalTitle, meta.title].forEach(function (value) {
    var key = titleKey(value);
    if (key && keys.indexOf(key) < 0) keys.push(key);
  });
  return keys;
}
function knownTitle(titles, meta) {
  var keys = metaKeys(meta);
  return titles.some(function (title) { return keys.indexOf(titleKey(title)) >= 0; });
}
function localPage(value, site) {
  var url = u.absolute(value, site + '/');
  return u.sameSite(url, site) && /^\/serial-\d+-[^?#]*\.html$/i.test(url.slice(u.origin(url).length)) && !/[\\\r\n]/.test(url) ? url : '';
}
function parseSearch(html, site, meta) {
  var results = [], seen = {}, re = /<div\b[^>]*class\s*=\s*["'][^"']*\bpgs-search-info\b[^"']*["'][^>]*>([\s\S]*?)<\/div\s*>/gi, match;
  html = cleanHtml(html);
  while ((match = re.exec(html)) && results.length < 12) {
    var links = /<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi, link, titles = [], url = '';
    while ((link = links.exec(match[1]))) {
      var next = localPage(u.attr(link[1], 'href'), site);
      if (!next || (url && next !== url)) continue;
      url = next;
      titles.push(u.text(link[2]));
    }
    if (url && !seen[url] && knownTitle(titles, meta)) {
      seen[url] = true;
      results.push({ url: url, titles: titles });
    }
  }
  return results;
}
function seasonNumber(value) {
  var match = /(?:^|\s)(\d+)\s*сезон(?:\s|$|[<(])/i.exec(u.text(value));
  return match ? parseInt(match[1], 10) : 1;
}
function parsePage(html, site, pageUrl) {
  html = cleanHtml(html);
  var heading = u.classText(html, 'pgs-sinfo-title');
  var original = /Оригинал\s*:\s*<span\b[^>]*>([\s\S]*?)<\/span\s*>/i.exec(html);
  var year = /Вышел\s*:\s*<span\b[^>]*>\s*((?:19|20)\d{2})\s*<\/span\s*>/i.exec(html);
  var titles = heading.replace(/^\s*Сериал\s+/i, '').replace(/\s+онлайн\s*$/i, '').split('/');
  if (original) titles.push(u.text(original[1]));
  var section = /<div\b[^>]*class\s*=\s*["'][^"']*\bpgs-seaslist\b[^"']*["'][^>]*>([\s\S]*?)<\/div\s*>/i.exec(html);
  var seasons = {}, links = /<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi, link;
  if (section) {
    while ((link = links.exec(section[1]))) {
      var url = localPage(u.attr(link[1], 'href'), site);
      if (url) seasons[seasonNumber(link[2])] = url;
    }
  }
  if (!Object.keys(seasons).length && heading && localPage(pageUrl, site)) seasons[seasonNumber(heading)] = pageUrl;
  return { titles: titles, year: year ? parseInt(year[1], 10) : 0, season: seasonNumber(heading), seasons: seasons };
}
function stringData(value) {
  return value.replace(/\\(u[\da-fA-F]{4}|x[\da-fA-F]{2}|[\\/"'nrt])/g, function (all, escaped) {
    if (escaped.charAt(0) === 'u' || escaped.charAt(0) === 'x') return String.fromCharCode(parseInt(escaped.slice(1), 16));
    return { n: '\n', r: '\r', t: '\t' }[escaped] || escaped;
  });
}
function playlists(html, site) {
  html = cleanHtml(html);
  var urls = {}, labels = {}, match, initial = /\bvar\s+pl\s*=\s*\{([\s\S]{0,12000}?)\}\s*;/i.exec(html);
  var props = /["'](\d+)["']\s*:\s*(["'])((?:\\.|[^\\])*?)\2/g;
  if (initial) while ((match = props.exec(initial[1]))) urls[match[1]] = stringData(match[3]);
  var assignments = /\bpl\s*\[\s*["']?(\d+)["']?\s*\]\s*=\s*(["'])((?:\\.|[^\\])*?)\2\s*;/g;
  while ((match = assignments.exec(html))) urls[match[1]] = stringData(match[3]);
  var items = /<li\b([^>]*)>([\s\S]*?)<\/li\s*>/gi;
  while ((match = items.exec(html))) {
    var id = u.attr(match[1], 'data-translate');
    if (/^\d+$/.test(id)) labels[id] = u.text(match[2]);
  }
  return Object.keys(urls).map(function (id) {
    var url = u.absolute(urls[id], site + '/');
    var title = labels[id] || (id === '0' ? 'Стандартный' : 'Перевод ' + id);
    if (!u.sameSite(url, site) || !/^\/playls2?\//i.test(url.slice(u.origin(url).length)) || /[\\\r\n]/.test(url) || /трейлер|trailer/i.test(title) || id === '68') return null;
    return { url: url, title: title, id: id };
  }).filter(function (item) { return !!item; }).slice(0, 4);
}
function base64(value) {
  if (!value || value.length > 32768 || !/^[A-Za-z0-9+/]*={0,2}$/.test(value) || value.length % 4 === 1) return '';
  var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/', out = '', bits = 0, buffer = 0;
  for (var i = 0; i < value.length; i++) {
    if (value.charAt(i) === '=') break;
    var n = alphabet.indexOf(value.charAt(i));
    if (n < 0) return '';
    buffer = (buffer << 6) | n;
    bits += 6;
    if (bits >= 8) { bits -= 8; out += String.fromCharCode((buffer >> bits) & 255); }
  }
  try {
    return decodeURIComponent(out.replace(/[\s\S]/g, function (character) { return '%' + ('0' + character.charCodeAt(0).toString(16)).slice(-2); }));
  } catch (ignore) { return ''; }
}
function decodedFile(value) {
  value = String(value || '');
  if (value.slice(0, 2) === '#2') return base64(value.slice(2).split('//b2xvbG8=').join(''));
  return value.charAt(0) === '#' ? '' : value;
}
function media(value, site) {
  var url = u.absolute(value, site + '/');
  return !/[\s\\]/.test(url) && /^https?:\/\/[^/?#@\s]+\/[^\r\n\\]*\.(?:mp4|m3u8)(?:[?#][^\r\n\\]*)?$/i.test(url) ? url : '';
}
function subtitles(value, site) {
  value = decodedFile(value);
  if (!value) return [];
  var tracks = [], re = /\[([^\]]{1,40})\]([^\[]+)/g, match;
  while ((match = re.exec(value)) && tracks.length < 8) tracks.push({ label: u.text(match[1]), file: match[2].trim().replace(/,+$/, '') });
  if (!tracks.length) tracks.push({ label: '', file: value });
  var seen = {}, out = [];
  tracks.forEach(function (track) {
    var url = u.absolute(track.file, site + '/');
    if (seen[url] || /[\s\\]/.test(url) || !/^https?:\/\/[^/?#@\s]+\/[^\r\n\\]*\.(?:vtt|srt)(?:[?#][^\r\n\\]*)?$/i.test(url)) return;
    seen[url] = true;
    var label = track.label, lang = /^(?:ru|rus|русский|russian)$/i.test(label) ? 'ru' : /^(?:en|eng|английский|english)$/i.test(label) ? 'en' : /^[a-z]{2,3}$/i.test(label) ? label.toLowerCase() : 'und';
    out.push({ url: url, lang: lang, label: lang === 'ru' ? 'Русский' : lang === 'en' ? 'English' : label || 'Subtitles' });
  });
  return out;
}
function episodeStreams(playlist, episode, translation, site, pageUrl) {
  if (!Array.isArray(playlist) || playlist.length > 1000) return [];
  var selected = playlist.filter(function (entry) { return entry && String(entry.id) === String(episode); });
  if (selected.length !== 1) return [];
  var item = selected[0], file = decodedFile(item.file), out = [], seen = {};
  var voice = u.text(String(item.title || '').split(/<br\s*\/?\s*>/i).slice(1).join(' ')) || translation.title;
  var qualities = [], re = /\[([^\]]{1,32})\]([^\[]+)/g, match;
  while ((match = re.exec(file))) qualities.push({ quality: match[1], file: match[2].trim().replace(/,+$/, '') });
  if (!qualities.length) qualities.push({ quality: '', file: file });
  qualities.slice(0, 3).forEach(function (entry) {
    var url = media(entry.file, site);
    if (!url || seen[url]) return;
    seen[url] = true;
    var q = /(?:^|\D)(2160|1080|720|480|360)(?:p|\D|$)/i.exec(entry.quality);
    var candidate = { url: url, quality: q ? q[1] + 'p' : '', type: /\.m3u8(?:[?#]|$)/i.test(url) ? 'hls' : 'mp4', title: 'Seasonvar · ' + voice, headers: { Referer: pageUrl, Origin: site } };
    var tracks = subtitles(item.subtitle, site);
    if (tracks.length) candidate.subtitles = tracks;
    out.push(candidate);
  });
  return out;
}
function resolve(meta, season, episode, cfg, client) {
  season = Number(season);
  episode = Number(episode);
  if (!meta || meta.type !== 'tv' || !isFinite(Number(season)) || season < 1 || Math.floor(season) !== Number(season) || !isFinite(Number(episode)) || episode < 1 || Math.floor(episode) !== Number(episode)) return Promise.resolve([]);
  var site = u.siteUrl(cfg && cfg.seasonvarSite) || 'https://seasonvar.ru';
  var queries = [];
  [meta.originalTitle, meta.title].forEach(function (value) { if (value && queries.indexOf(value) < 0 && String(value).length <= 160) queries.push(value); });
  if (!queries.length) return Promise.resolve([]);
  function search(index) {
    if (index >= Math.min(queries.length, 2)) return Promise.resolve([]);
    return client.request(site + '/search?q=' + encodeURIComponent(queries[index]), { referer: site + '/', timeout: 10000 }).then(function (html) {
      var results = parseSearch(html, site, meta);
      return results.length ? results.slice(0, 2) : search(index + 1);
    });
  }
  function candidate(result) {
    return client.request(result.url, { referer: site + '/', timeout: 10000 }).then(function (html) {
      var page = parsePage(html, site, result.url);
      if (!knownTitle(page.titles, meta) || !page.seasons[season]) return [];
      var wantedUrl = page.seasons[season], firstUrl = page.seasons[1];
      if (!firstUrl) return [];
      function pageBody(url) { return url === result.url ? Promise.resolve(html) : client.request(url, { referer: result.url, timeout: 10000 }); }
      return Promise.all([pageBody(wantedUrl), wantedUrl === firstUrl ? Promise.resolve(null) : pageBody(firstUrl)]).then(function (bodies) {
        var selected = parsePage(bodies[0], site, wantedUrl), first = parsePage(bodies[1] || bodies[0], site, firstUrl);
        if (!knownTitle(selected.titles, meta) || selected.season !== Number(season) || first.season !== 1 || !knownTitle(first.titles, meta)) return [];
        if (meta.year && first.year && Math.abs(Number(meta.year) - first.year) > 1) return [];
        var sources = playlists(bodies[0], site);
        return Promise.all(sources.map(function (translation) {
          return client.request(translation.url, { json: true, referer: wantedUrl, timeout: 10000 }).then(function (playlist) {
            return episodeStreams(playlist, episode, translation, site, wantedUrl);
          }).catch(function (error) { if (error && error.siteBlocked) throw error; return []; });
        })).then(function (lists) { var out = []; lists.forEach(function (list) { out = out.concat(list); }); return out; });
      });
    });
  }
  return search(0).then(function (results) {
    function next(index) {
      if (index >= results.length) return Promise.resolve([]);
      return candidate(results[index]).then(function (streams) { return streams.length ? streams : next(index + 1); });
    }
    return next(0);
  });
}

module.exports = { resolve: resolve, parseSearch: parseSearch, parsePage: parsePage, playlists: playlists, decodedFile: decodedFile, episodeStreams: episodeStreams };
