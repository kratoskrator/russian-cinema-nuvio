'use strict';
var u = require('./utils');
var DEFAULT_API = 'https://api.srvkp.com';
var MAX_STREAMS = 3;

function safeError(message) {
  var error = new Error('KinoPub: ' + message);
  error.providerSafe = true;
  return error;
}

function imdb(value) {
  value = String(value || '').replace(/^tt/i, '');
  return /^\d{1,10}$/.test(value) && Number(value) > 0 ? String(Number(value)) : '';
}

function kind(item) {
  var type = String(item && item.type || '').toLowerCase();
  if (['serial', 'docuserial', 'tvshow', 'tv', 'series'].indexOf(type) !== -1) return 'tv';
  if (['movie', 'documovie', '4k', '3d', 'concert'].indexOf(type) !== -1) return 'movie';
  return '';
}

function matchScore(item, meta) {
  if (!item || !/^\d+$/.test(String(item.id || '')) || kind(item) !== meta.type) return -1;
  var actualImdb = imdb(item.imdb || item.imdb_id), wantedImdb = imdb(meta.imdb);
  if (wantedImdb && actualImdb && actualImdb !== wantedImdb) return -1;
  if (wantedImdb && actualImdb === wantedImdb) return 200;
  var names = String(item.title || '').split(/\s*\/\s*/).concat([item.original_title || '']).map(u.normalize).filter(Boolean);
  var titles = [meta.title, meta.originalTitle].map(u.normalize).filter(Boolean);
  if (!titles.some(function (title) { return names.indexOf(title) !== -1; })) return -1;
  var year = Number(String(item.year || '').slice(0, 4));
  if (!meta.year || !year || Math.abs(year - Number(meta.year)) > 1) return -1;
  return year === Number(meta.year) ? 120 : 100;
}

function selectResult(items, meta) {
  if (!Array.isArray(items)) return null;
  var best = null, score = -1;
  items.slice(0, 100).forEach(function (item) {
    var next = matchScore(item, meta);
    if (next > score) { score = next; best = item; }
  });
  return best;
}

function selectedMedia(item, type, season, episode) {
  if (!item) return null;
  if (type === 'movie') {
    // The API can contain trailers/parts, so prefer the explicitly numbered main video.
    var videos = Array.isArray(item.videos) ? item.videos : [];
    return videos.filter(function (video) { return Number(video.number) === 1; })[0] || (videos.length === 1 ? videos[0] : null);
  }
  var seasons = Array.isArray(item.seasons) ? item.seasons : [];
  var chosen = seasons.filter(function (entry) { return Number(entry.number) === Number(season); })[0];
  return chosen && Array.isArray(chosen.episodes) ? chosen.episodes.filter(function (entry) { return Number(entry.number) === Number(episode); })[0] || null : null;
}

function safeMediaUrl(value, token) {
  value = String(value || '');
  if (!/^https:\/\/[a-z0-9.-]+(?::\d+)?\/[^\s#]*$/i.test(value)) return '';
  // Signed CDN URLs are expected; an account access token is never a playback credential.
  if (/[?&](?:access_token|authorization|api_key)=/i.test(value)) return '';
  if (token && (value.indexOf(token) !== -1 || value.indexOf(encodeURIComponent(token)) !== -1)) return '';
  return value;
}

function fileQuality(file) {
  var declared = /^(\d{3,4})(?:p)?$/i.exec(String(file.quality || ''));
  var height = Number(file.h || file.height), width = Number(file.w || file.width);
  var value = declared ? Number(declared[1]) : height || 0;
  if (width > 0 && height > 0) {
    // Cropped cinema encodes retain their standard width tier, but a claimed
    // 4K label on a 1920-wide file must never become a verified 4K result.
    if (width >= 7680 && height >= 3000) value = 4320;
    else if (width >= 3840 && height >= 1500) value = 2160;
    else if (width >= 2560 && height >= 1000) value = 1440;
    else if (width >= 1920 && height >= 700) value = 1080;
    else if (width >= 1280 && height >= 460) value = 720;
    else value = Math.min(value || height, height);
  }
  if (value < 240 || value > 4320) return '';
  return value + 'p';
}

function streamsFromLinks(data, media, token) {
  if (!data || !Array.isArray(data.files)) return [];
  var seen = {}, result = [];
  var subtitles = (Array.isArray(data.subtitles) ? data.subtitles : Array.isArray(media.subtitles) ? media.subtitles : []).slice(0, 20).filter(function (sub) {
    return safeMediaUrl(sub.url, token);
  }).map(function (sub, index) {
    return { id: 'kinopub-sub-' + index, url: sub.url, language: sub.lang || 'ru', name: sub.lang || 'Subtitle', headers: {} };
  });
  data.files.slice(0, 30).sort(function (a, b) { return parseInt(fileQuality(b), 10) - parseInt(fileQuality(a), 10); }).forEach(function (file) {
    var urls = file.urls || file.url || {};
    if (typeof urls !== 'object') return;
    var quality = fileQuality(file);
    if (!quality) return;
    // One HLS transport per encoding avoids exposing several equivalent paid sessions.
    var value = safeMediaUrl(urls.hls4 || urls.hls || urls.hls2, token);
    var type = 'hls';
    if (!value) { value = safeMediaUrl(urls.http, token); type = 'mp4'; }
    if (!value || seen[value] || result.length >= MAX_STREAMS) return;
    seen[value] = true;
    var codec = u.text(file.codec || '').slice(0, 20);
    result.push({
      url: value, type: type, quality: quality, title: 'KinoPub | ' + quality + (codec ? ' | ' + codec : ''),
      headers: {}, subtitles: subtitles, codecSummary: codec + (Number(file.w) && Number(file.h) ? ' ' + file.w + 'x' + file.h : ''),
      // Fetching a paid manifest can open a viewing session. The authenticated
      // media-links response supplies the exact file metadata; do not bulk-probe.
      metadataVerified: true
    });
  });
  return result;
}

function resolve(meta, season, episode, cfg, client) {
  cfg = cfg || {};
  var token = String(cfg.kinopubToken || '').trim();
  if (!token) return Promise.resolve([]);
  if (/\s/.test(token) || token.length > 4096) return Promise.reject(safeError('Invalid access token setting.'));
  var api = u.siteUrl(cfg.kinopubApi || DEFAULT_API);
  if (!api) return Promise.reject(safeError('The API address must use HTTPS.'));
  if (!meta || ['movie', 'tv'].indexOf(meta.type) === -1) return Promise.resolve([]);
  if (meta.type === 'tv' && (!/^\d+$/.test(String(season)) || !/^\d+$/.test(String(episode)) || Number(episode) < 1)) return Promise.resolve([]);
  function request(path, values) {
    var url = api + '/v1/' + path + (values ? '?' + u.form(values) : '');
    return client.request(url, { json: true, headers: { Authorization: 'Bearer ' + token }, sensitive: true, timeout: 10000 }).then(function (data) {
      if (!data || data.error || Number(data.status) >= 400) throw safeError('Account access failed. Check your own access token and subscription.');
      return data;
    });
  }
  var queries = [meta.originalTitle, meta.title].filter(function (value, index, all) { return value && all.indexOf(value) === index; }).slice(0, 2);
  function search(index) {
    if (index >= queries.length) return Promise.resolve(null);
    return request('items/search', { q: queries[index], field: 'title', perpage: 50 }).then(function (data) {
      return selectResult(data.items, meta) || search(index + 1);
    });
  }
  return search(0).then(function (match) {
    if (!match) return [];
    return request('items/' + match.id, { nolinks: 1 }).then(function (data) {
      var item = data.item;
      if (!item || String(item.id) !== String(match.id) || matchScore(item, meta) < 0) return [];
      var media = selectedMedia(item, meta.type, season, episode);
      if (!media) return [];
      var mid = media.id || media.mid || media.media_id;
      if (/^\d+$/.test(String(mid || ''))) {
        return request('items/media-links', { mid: mid }).then(function (links) { return streamsFromLinks(links, media, token); });
      }
      // Older API deployments return the selected video's links in the item.
      return streamsFromLinks(media, media, token);
    });
  }).catch(function () {
    // API bodies/transport errors can echo an account token. Diagnostics are fixed text.
    throw safeError('Account/API request failed. Check your own access token, subscription, and HTTPS API address.');
  });
}

module.exports = { resolve: resolve, matchScore: matchScore, selectResult: selectResult, selectedMedia: selectedMedia, streamsFromLinks: streamsFromLinks, fileQuality: fileQuality };
