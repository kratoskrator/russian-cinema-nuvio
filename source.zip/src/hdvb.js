'use strict';
var u = require('./utils');
var DEFAULT_API = 'https://apivb.com';
var MAX_VOICES = 2;

function safeError(message) {
  var error = new Error('HDVB: ' + message);
  error.providerSafe = true;
  return error;
}

function imdb(value) {
  value = String(value || '').replace(/^tt/i, '');
  return /^\d{1,10}$/.test(value) && Number(value) > 0 ? String(Number(value)) : '';
}

function matchScore(item, meta) {
  if (!item) return -1;
  var type = String(item.type || '').toLowerCase();
  var actualType = type === 'movie' ? 'movie' : ['serial', 'series', 'tv'].indexOf(type) !== -1 ? 'tv' : '';
  if (actualType !== meta.type) return -1;
  var wantedImdb = imdb(meta.imdb), actualImdb = imdb(item.imdb_id || item.imdb);
  if (wantedImdb && actualImdb && wantedImdb !== actualImdb) return -1;
  if (wantedImdb && wantedImdb === actualImdb) return 200;
  var names = [item.title_ru, item.title_en, item.title, item.original_title].map(u.normalize).filter(Boolean);
  var titles = [meta.title, meta.originalTitle].map(u.normalize).filter(Boolean);
  var year = Number(String(item.year || '').slice(0, 4));
  if (!titles.some(function (title) { return names.indexOf(title) !== -1; })) return -1;
  if (!year || !meta.year || Math.abs(year - Number(meta.year)) > 1) return -1;
  return year === Number(meta.year) ? 120 : 100;
}

function validHttps(value) {
  return /^https:\/\/[a-z0-9.-]+(?::\d+)?\/[^\s#]*$/i.test(String(value || ''));
}

function safePlayback(value, token) {
  value = String(value || '');
  if (!validHttps(value) || /[?&](?:access_token|authorization|api_key)=/i.test(value)) return '';
  if (token && (value.indexOf(token) !== -1 || value.indexOf(encodeURIComponent(token)) !== -1)) return '';
  return value;
}

function field(html, name) {
  var match = new RegExp('"' + name + '"\\s*:\\s*("(?:[^"\\\\]|\\\\.)*")').exec(String(html || ''));
  if (!match) return '';
  try { return JSON.parse(match[1]); } catch (ignored) { return ''; }
}

function playerConfig(html, iframe) {
  var host = field(html, 'href'), key = field(html, 'key'), file = field(html, 'file');
  var vid = field(html, 'vid');
  if (!/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}$/i.test(host) || host.indexOf('..') !== -1) return null;
  if (!key || key.length > 4096 || /[\r\n]/.test(key)) return null;
  var root = u.origin(iframe);
  if (!/^https:\/\//i.test(root)) return null;
  return { base: 'https://' + (/^vid\d+$/.test(vid) ? vid : 'vid11') + '.' + host, key: key, file: file, origin: root };
}

function playlistUrl(file, config) {
  file = String(file || '').replace(/^\/playlist\//, '').replace(/^\/+/, '').replace(/\.txt$/, '');
  if (!file || file.length > 2048 || !/^[a-z0-9_/-]+$/i.test(file) || /(?:^|\/)\.\.(?:\/|$)/.test(file)) return '';
  return config.base + '/playlist/' + file + '.txt';
}

function parseJson(value) {
  if (value && typeof value === 'object') return value;
  try { return JSON.parse(String(value || '')); } catch (ignored) { return null; }
}

function selectedEpisode(data, season, episode, translator) {
  if (!Array.isArray(data)) return null;
  var selected = data.filter(function (entry) { return Number(entry.id !== undefined ? entry.id : entry.season) === Number(season); })[0];
  if (!selected || !Array.isArray(selected.folder)) return null;
  var ep = selected.folder.filter(function (entry) { return Number(entry.episode) === Number(episode); })[0];
  if (!ep || !Array.isArray(ep.folder)) return null;
  var voices = ep.folder;
  var wanted = u.normalize(translator);
  var chosen = wanted ? voices.filter(function (entry) { return u.normalize(entry.title) === wanted; })[0] : null;
  return chosen || (!wanted && voices.length === 1 ? voices[0] : null);
}

function mediaUrls(body, token, title, headers) {
  var parsed = parseJson(body), value = typeof parsed === 'string' ? parsed : parsed && typeof parsed.file === 'string' ? parsed.file : String(body || '').trim();
  var result = [], seen = {}, match;
  var tagged = /\[(\d{3,4})p?\]\s*(https:\/\/[^,\s"<>]+)/gi;
  while ((match = tagged.exec(value)) && result.length < 4) {
    if (Number(match[1]) < 240 || Number(match[1]) > 4320) continue;
    var url = safePlayback(match[2], token);
    if (!url || !/\.m3u8(?:[?#]|$)/i.test(url) || seen[url]) continue;
    seen[url] = true;
    result.push({ url: url, type: 'hls', quality: match[1] + 'p', title: title, headers: headers });
  }
  if (result.length) return result;
  var direct = /https:\/\/[^\s"<>]+?\.m3u8(?:\?[^\s"<>]*)?/i.exec(value.replace(/\\\//g, '/'));
  var url = direct && safePlayback(direct[0], token);
  return url ? [{ url: url, type: 'hls', quality: 'Auto', title: title, headers: headers }] : [];
}

function resolveFrame(item, meta, season, episode, token, client) {
  var iframe = safePlayback(item.iframe_url, token);
  if (!iframe) return Promise.resolve([]);
  var title = 'HDVB' + (item.translator ? ' | ' + u.text(item.translator).slice(0, 100) : '');
  return client.request(iframe, { referer: u.origin(iframe) + '/', timeout: 10000 }).then(function (html) {
    var config = playerConfig(html, iframe);
    if (!config) return [];
    var playbackHeaders = { Referer: config.origin + '/', Origin: config.origin };
    function post(file) {
      var url = playlistUrl(file, config);
      if (!url) return Promise.resolve('');
      return client.request(url, {
        method: 'POST', body: '', origin: config.origin, referer: config.origin + '/',
        headers: { 'X-CSRF-Token': config.key, Accept: '*/*' }, timeout: 10000
      });
    }
    return post(config.file).then(function (body) {
      if (meta.type === 'tv') {
        var selected = selectedEpisode(parseJson(body), season, episode, item.translator);
        if (!selected) return [];
        return post(selected.file).then(function (value) { return mediaUrls(value, token, title, playbackHeaders); });
      }
      var streams = mediaUrls(body, token, title, playbackHeaders);
      if (streams.length) return streams;
      var pointer = parseJson(body);
      return pointer && typeof pointer.file === 'string' ? post(pointer.file).then(function (value) { return mediaUrls(value, token, title, playbackHeaders); }) : [];
    });
  });
}

function resolve(meta, season, episode, cfg, client) {
  cfg = cfg || {};
  var token = String(cfg.hdvbToken || '').trim();
  if (!token) return Promise.resolve([]);
  if (/\s/.test(token) || token.length > 4096) return Promise.reject(safeError('Invalid partner token setting.'));
  var api = u.siteUrl(cfg.hdvbApi || DEFAULT_API);
  if (!api) return Promise.reject(safeError('The API address must use HTTPS.'));
  if (!meta || ['movie', 'tv'].indexOf(meta.type) === -1) return Promise.resolve([]);
  if (meta.type === 'tv' && (!/^\d+$/.test(String(season)) || !/^\d+$/.test(String(episode)) || Number(episode) < 1)) return Promise.resolve([]);
  var queries = [meta.originalTitle, meta.title].filter(function (value, index, all) { return value && all.indexOf(value) === index; }).slice(0, 2);
  function search(index) {
    if (index >= queries.length) return Promise.resolve([]);
    // HDVB's approved partner API requires the token as a query parameter.
    // Only this HTTPS API request receives it; iframe/CDN requests do not.
    var url = api + '/api/videos.json?' + u.form({ token: token, title: queries[index] });
    return client.request(url, { json: true, sensitive: true, timeout: 10000 }).then(function (data) {
      if (!Array.isArray(data)) throw safeError('Partner API access failed. Check your own approved partner token.');
      var matches = data.slice(0, 100).filter(function (item) { return matchScore(item, meta) >= 0; }).sort(function (a, b) { return matchScore(b, meta) - matchScore(a, meta); });
      if (!matches.length) return search(index + 1);
      return matches.slice(0, MAX_VOICES);
    });
  }
  return search(0).then(function (items) {
    return Promise.all(items.map(function (item) { return resolveFrame(item, meta, season, episode, token, client); }));
  }).then(function (groups) {
    return [].concat.apply([], groups).slice(0, 8);
  }).catch(function () {
    // Do not surface API query strings, echoed partner tokens, or player keys.
    throw safeError('Partner API/player request failed. Check your own approved partner token and HTTPS API address.');
  });
}

module.exports = { resolve: resolve, matchScore: matchScore, playerConfig: playerConfig, playlistUrl: playlistUrl, selectedEpisode: selectedEpisode, mediaUrls: mediaUrls };
