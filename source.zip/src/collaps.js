'use strict';
var u = require('./utils');
var USER_AGENT = require('./http').USER_AGENT;
var DEFAULT_SITE = 'https://api.luxembd.ws';
var MAX_DATA = 1024 * 1024;

// Read narrowly scoped public player data. The surrounding script, advertising
// callbacks and player libraries are never evaluated or downloaded.
function skipSpace(value, offset) {
  while (offset < value.length) {
    if (/\s/.test(value.charAt(offset))) { offset++; continue; }
    if (value.slice(offset, offset + 2) === '//') {
      offset = value.indexOf('\n', offset + 2);
      if (offset < 0) return value.length;
      continue;
    }
    if (value.slice(offset, offset + 2) === '/*') {
      var end = value.indexOf('*/', offset + 2);
      if (end < 0) return value.length;
      offset = end + 2;
      continue;
    }
    break;
  }
  return offset;
}

function valueEnd(value, start) {
  var stack = [], quote = '', escaped = false;
  for (var i = start; i < value.length; i++) {
    var ch = value.charAt(i);
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === quote) quote = '';
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (value.slice(i, i + 2) === '//' || value.slice(i, i + 2) === '/*') {
      var after = skipSpace(value, i);
      if (after >= value.length) return -1;
      i = after - 1;
      continue;
    }
    if (ch === '{' || ch === '[' || ch === '(') {
      stack.push(ch);
      if (stack.length > 32) return -1;
      continue;
    }
    if (ch === '}' || ch === ']' || ch === ')') {
      if (!stack.length) return i;
      var wanted = ch === '}' ? '{' : ch === ']' ? '[' : '(';
      if (stack.pop() !== wanted) return -1;
      if (!stack.length && (value.charAt(start) === '{' || value.charAt(start) === '[')) return i + 1;
    } else if (ch === ',' && !stack.length) return i;
  }
  return quote || stack.length ? -1 : value.length;
}

function properties(value) {
  if (typeof value !== 'string' || value.length > MAX_DATA || value.charAt(0) !== '{') return null;
  var out = {}, count = 0, offset = 1;
  while (offset < value.length && count++ < 128) {
    offset = skipSpace(value, offset);
    if (value.charAt(offset) === '}') return skipSpace(value, offset + 1) === value.length ? out : null;
    var key = /^([a-zA-Z_$][\w$]*)\s*:/.exec(value.slice(offset));
    if (!key) return null;
    if (Object.prototype.hasOwnProperty.call(out, key[1])) return null;
    offset = skipSpace(value, offset + key[0].length);
    var end = valueEnd(value, offset);
    if (end < 0) return null;
    out[key[1]] = value.slice(offset, end).trim();
    offset = skipSpace(value, end);
    if (value.charAt(offset) === ',') offset++;
    else if (value.charAt(offset) !== '}') return null;
  }
  return null;
}

function json(value) {
  if (typeof value !== 'string' || value.length > MAX_DATA) return null;
  try { return JSON.parse(value); } catch (ignored) { return null; }
}

function playerData(html) {
  if (typeof html !== 'string' || html.length > MAX_DATA) return null;
  var scripts = /<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi, match, selected = null;
  while ((match = scripts.exec(html))) {
    if (u.attr(match[1], 'data-name') !== 'mk') continue;
    if (selected !== null) return null;
    selected = match[2];
  }
  if (!selected) return null;
  var call = /\bmakePlayer\s*\(\s*\{/.exec(selected);
  if (!call) return null;
  var start = call.index + call[0].lastIndexOf('{');
  var end = valueEnd(selected, start);
  if (end < 0 || !/^\s*\)/.test(selected.slice(end))) return null;
  return properties(selected.slice(start, end));
}

function safeUrl(value, extension) {
  if (typeof value !== 'string' || value.length > 8192 || /[\s\\\x00-\x1f\x7f]/.test(value) || /%(?![a-f\d]{2})/i.test(value) || /%(?:0[0-9a-f]|1[0-9a-f]|20|5c|7f)/i.test(value)) return '';
  var parts = /^(https?):\/\/([a-z\d](?:[a-z\d.-]*[a-z\d])?)(?::(\d{1,5}))?(\/[\s\S]*)$/i.exec(value);
  if (!parts || parts[3] && (Number(parts[3]) < 1 || Number(parts[3]) > 65535)) return '';
  return new RegExp('\\.' + extension + '$', 'i').test(parts[4].split(/[?#]/)[0]) ? value : '';
}

function subtitles(value) {
  if (!Array.isArray(value)) return [];
  var seen = {};
  return value.slice(0, 32).map(function (track) {
    var url = track && safeUrl(track.url, '(?:vtt|srt)');
    if (!url || seen[url]) return null;
    seen[url] = true;
    var label = u.text(track.name || '').slice(0, 120);
    var lang = /^(?:Рус|Russian|ru\b)/i.test(label) ? 'ru' : /^(?:Eng|English|en\b)/i.test(label) ? 'en' : /^(?:Укр|Ukrainian|uk\b)/i.test(label) ? 'uk' : 'und';
    return { url: url, lang: lang, label: label || 'Subtitles' };
  }).filter(Boolean).slice(0, 16);
}

function audioLabels(value) {
  if (!value || !Array.isArray(value.names)) return [];
  return value.names.slice(0, 32).map(function (name) { return typeof name === 'string' ? u.text(name).slice(0, 120) : ''; }).filter(Boolean);
}

function sources(entry, site) {
  if (!entry || typeof entry !== 'object' || entry.blocked === true) return [];
  var tracks = subtitles(entry.cc), audio = audioLabels(entry.audio), seen = {};
  return ['dash', 'dasha', 'hls'].map(function (key) {
    var url = safeUrl(entry[key], key === 'hls' ? 'm3u8' : 'mpd');
    if (!url || seen[url]) return null;
    seen[url] = true;
    var out = {
      url: url, type: key === 'hls' ? 'hls' : 'dash',
      title: 'Collaps | ' + (key === 'dash' ? 'DASH' : key === 'dasha' ? 'DASH alternate' : 'HLS') + (audio.length > 1 ? ' | Multiple audio tracks' : audio.length === 1 ? ' | ' + audio[0] : ''),
      headers: { Referer: site + '/', Origin: site, 'User-Agent': USER_AGENT, Accept: '*/*' }
    };
    if (tracks.length) out.subtitles = tracks;
    if (audio.length) out.audio = audio;
    return out;
  }).filter(Boolean);
}

function candidates(html, meta, season, episode, site) {
  var data = playerData(html);
  if (!data || data.blocked === 'true') return [];
  if (meta.type === 'movie') {
    if (data.playlist || !data.source) return [];
    var source = properties(data.source);
    if (!source) return [];
    var entry = {};
    ['dash', 'dasha', 'hls', 'audio', 'cc', 'blocked'].forEach(function (key) { entry[key] = json(source[key]); });
    return sources(entry, site);
  }
  var playlist = properties(data.playlist), seasons = playlist && json(playlist.seasons);
  if (!Array.isArray(seasons) || seasons.length > 100) return [];
  var selectedSeasons = seasons.filter(function (item) { return item && String(item.season) === String(season); });
  if (selectedSeasons.length !== 1 || selectedSeasons[0].blocked === true) return [];
  var episodes = selectedSeasons[0].episodes;
  if (!Array.isArray(episodes) || episodes.length > 1000) return [];
  var selectedEpisodes = episodes.filter(function (item) { return item && String(item.episode) === String(episode); });
  return selectedEpisodes.length === 1 ? sources(selectedEpisodes[0], site) : [];
}

function resolve(meta, season, episode, cfg, client) {
  if (!meta || ['movie', 'tv'].indexOf(meta.type) === -1 || !/^tt\d{7,10}$/.test(String(meta.imdb || ''))) return Promise.resolve([]);
  if (meta.type === 'tv' && (!/^\d+$/.test(String(season)) || !/^\d+$/.test(String(episode)) || Number(episode) < 1)) return Promise.resolve([]);
  if (cfg && cfg.deadline && cfg.deadline <= Date.now()) return Promise.resolve([]);
  var site = u.siteUrl(cfg && cfg.collapsSite) || DEFAULT_SITE;
  return client.request(site + '/embed/imdb/' + meta.imdb, { referer: site + '/', timeout: 10000 }).then(function (html) {
    return candidates(html, meta, Number(season), Number(episode), site).slice(0, 8);
  });
}

module.exports = { resolve: resolve, candidates: candidates, playerData: playerData, safeUrl: safeUrl };
