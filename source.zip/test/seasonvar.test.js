'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const provider = require('../src/seasonvar');
const site = 'https://seasonvar.ru';
const first = site + '/serial-101-Example-1-season.html';
const second = site + '/serial-102-Example-2-season.html';
const meta = { type: 'tv', title: 'Пример', originalTitle: 'The Example', year: 2020 };

function searchResult(url, original = 'The Example', title = 'Пример') {
  return '<div class="pgs-search-info"><a href="' + url + '">' + title + '</a><br><a href="' + url + '">' + original + '</a><span>Сезонов: 2</span></div>';
}
function page(season, year, playlistId, names = true) {
  return '<h1 class="pgs-sinfo-title">Сериал Пример/The Example ' + season + ' сезон онлайн</h1>' +
    '<div>Оригинал: <span>The Example</span></div><div>Вышел: <span>' + year + '</span></div>' +
    '<div class="pgs-seaslist"><a href="' + first + '">Сериал Пример/The Example 1 сезон</a><a href="' + second + '">Сериал Пример/The Example 2 сезон</a></div>' +
    '<script>var pl = {\'0\': "/playls2/public/trans/' + playlistId + '/plist.txt?time=123"};</script>' +
    (names ? '<li data-translate="0">Стандартный</li>' : '');
}
function encoded(url) {
  const raw = Buffer.from(url).toString('base64');
  return '#2' + raw.slice(0, 11) + '//b2xvbG8=' + raw.slice(11);
}
function fixtureClient(entries) {
  const calls = [];
  return { calls, request(url, options) {
    calls.push({ url, options });
    if (!(url in entries)) return Promise.reject(new Error('Unexpected test route'));
    if (entries[url] instanceof Error) return Promise.reject(entries[url]);
    return Promise.resolve(entries[url]);
  } };
}

test('search uses exact translated or original titles and ignores sidebar links', () => {
  const html = '<a href="/serial-999-Example.html">The Example</a>' + searchResult('/serial-201-Other.html', 'The Example Returns', 'Пример: Продолжение') +
    searchResult(second) + '<!--' + searchResult(first) + '-->';
  assert.deepEqual(provider.parseSearch(html, site, meta), [{ url: second, titles: ['Пример', 'The Example'] }]);
});

test('search excludes foreign origins, userinfo, non-series pages and URL fragments', () => {
  const bad = ['https://ads.test/serial-101-Example.html', 'https://seasonvar.ru@ads.test/serial-101-Example.html', '/serial-101-Example.html?next=1', '/serial-101-Example.html#other', '/search', 'javascript:alert(1)', '//ads.test/serial-101-Example.html'];
  assert.deepEqual(provider.parseSearch(bad.map(url => searchResult(url)).join(''), site, meta), []);
});

test('page selects season links from the season list and reads the release year', () => {
  const parsed = provider.parsePage(page(2, 2022, 102) + '<a href="/serial-900-Other.html">3 сезон</a>', site, second);
  assert.equal(parsed.season, 2);
  assert.equal(parsed.year, 2022);
  assert.deepEqual(parsed.seasons, { 1: first, 2: second });
});

test('single-season pages without a season label are treated as season one', () => {
  const html = '<h1 class="pgs-sinfo-title">Сериал Пример/The Example онлайн</h1><div>Вышел: <span>2020</span></div>';
  assert.deepEqual(provider.parsePage(html, site, first).seasons, { 1: first });
});

test('playlist parsing reads static assignments without executing page scripts', () => {
  const html = page(1, 2020, 101) + '<script>throw new Error("must not execute");pl[6] = "/playls2/public/transOther/101/plist.txt?time=123";</script><li data-translate="6">Другой &amp; перевод</li>';
  assert.deepEqual(provider.playlists(html, site), [
    { id: '0', title: 'Стандартный', url: site + '/playls2/public/trans/101/plist.txt?time=123' },
    { id: '6', title: 'Другой & перевод', url: site + '/playls2/public/transOther/101/plist.txt?time=123' }
  ]);
});

test('playlist parsing excludes trailers, unrelated paths and external URLs', () => {
  const html = page(1, 2020, 101) + '<script>pl[68]="/playls2/a/trailer.txt";pl[5]="https://ads.test/playls2/a.txt";pl[9]="/unrelated.txt";pl[12]="/playls2/a/trailer.txt";</script><li data-translate="12">Трейлеры</li>';
  assert.equal(provider.playlists(html, site).length, 1);
});

test('Playerjs decoding removes only the known public marker and decodes UTF-8 data', () => {
  assert.equal(provider.decodedFile(encoded('//cdn.test/video.mp4')), '//cdn.test/video.mp4');
  assert.equal(provider.decodedFile(encoded('https://cdn.test/пример.mp4')), 'https://cdn.test/пример.mp4');
  assert.equal(provider.decodedFile(encoded('https://cdn.test/a%2Fb%20c.mp4?signature=%2B%2F%3D')), 'https://cdn.test/a%2Fb%20c.mp4?signature=%2B%2F%3D');
  assert.equal(provider.decodedFile('#3unknown-format'), '');
  assert.equal(provider.decodedFile('#2invalid$base64'), '');
  assert.equal(provider.decodedFile('#2' + 'a'.repeat(40000)), '');
});

test('episode selection returns the requested ID with its voiceover and playback headers', () => {
  const result = provider.episodeStreams([
    { id: '1', file: encoded('//cdn.test/first.mp4') },
    { id: '2', file: encoded('//cdn.test/second.mp4'), title: '2 серия SD/FullHD<br>LostFilm' }
  ], 2, { title: 'Стандартный' }, site, first);
  assert.deepEqual(result, [{ url: 'https://cdn.test/second.mp4', quality: '', type: 'mp4', title: 'Seasonvar · LostFilm', headers: { Referer: first, Origin: site } }]);
});

test('missing or ambiguous episode IDs never fall back to another episode', () => {
  assert.deepEqual(provider.episodeStreams([{ id: '1', file: '//cdn.test/first.mp4' }], 2, { title: 'Ru' }, site, first), []);
  assert.deepEqual(provider.episodeStreams([{ id: '2', file: '//cdn.test/a.mp4' }, { id: '2', file: '//cdn.test/b.mp4' }], 2, { title: 'Ru' }, site, first), []);
});

test('subtitle tracks preserve URL escapes and identify Russian and English', () => {
  const result = provider.episodeStreams([{ id: '1', file: '//cdn.test/first.mp4', subtitle: '[ru]/sub/first%20episode.vtt?shift=0,[English]https://cdn.test/first.srt' }], 1, { title: 'Субтитры' }, site, first);
  assert.deepEqual(result[0].subtitles, [
    { url: site + '/sub/first%20episode.vtt?shift=0', lang: 'ru', label: 'Русский' },
    { url: 'https://cdn.test/first.srt', lang: 'en', label: 'English' }
  ]);
  const unsafe = provider.episodeStreams([{ id: '1', file: '//cdn.test/first.mp4', subtitle: '[ru]javascript:alert(1),[en]https://user:pass@cdn.test/a.vtt' }], 1, { title: 'Ru' }, site, first);
  assert.equal(unsafe[0].subtitles, undefined);
});

test('quality options preserve explicitly labelled qualities and reject unsafe media', () => {
  const file = encoded('[720p]//cdn.test/a.mp4,[1080p]https://cdn.test/b.m3u8');
  const result = provider.episodeStreams([{ id: '1', file }], 1, { title: 'Ru' }, site, first);
  assert.deepEqual(result.map(item => [item.quality, item.type, item.url]), [['720p', 'mp4', 'https://cdn.test/a.mp4'], ['1080p', 'hls', 'https://cdn.test/b.m3u8']]);
  ['javascript:alert(1)', 'https://cdn.test/player.html', 'https://user:pass@cdn.test/a.mp4', 'https://cdn.test/a\n.mp4'].forEach(url => {
    assert.deepEqual(provider.episodeStreams([{ id: '1', file: url }], 1, { title: 'Ru' }, site, first), []);
  });
});

test('resolve follows the requested season and checks the first-season year', async () => {
  const entries = {};
  entries[site + '/search?q=The%20Example'] = searchResult(second);
  entries[second] = page(2, 2022, 102);
  entries[first] = page(1, 2020, 101);
  entries[site + '/playls2/public/trans/102/plist.txt?time=123'] = [{ id: '1', file: encoded('//cdn.test/s2e1.mp4') }];
  const client = fixtureClient(entries);
  const streams = await provider.resolve(meta, 2, 1, { seasonvarSite: site }, client);
  assert.equal(streams[0].url, 'https://cdn.test/s2e1.mp4');
  assert.equal(client.calls.length, 4);
  assert.equal(client.calls[3].options.referer, second);
});

test('resolve refuses a same-name series from a different release year', async () => {
  const entries = {};
  entries[site + '/search?q=The%20Example'] = searchResult(first);
  entries[first] = page(1, 2000, 101);
  const client = fixtureClient(entries);
  assert.deepEqual(await provider.resolve(meta, 1, 1, {}, client), []);
  assert.equal(client.calls.length, 2);
});

test('resolve never requests the player when the requested season does not exist', async () => {
  const entries = {};
  entries[site + '/search?q=The%20Example'] = searchResult(first);
  entries[first] = page(1, 2020, 101);
  const client = fixtureClient(entries);
  assert.deepEqual(await provider.resolve(meta, 3, 1, {}, client), []);
  assert.equal(client.calls.length, 2);
});

test('resolve uses translated-title search if original-title search has no exact result', async () => {
  const entries = {};
  entries[site + '/search?q=The%20Example'] = searchResult(second, 'Unrelated', 'Другое');
  entries[site + '/search?q=' + encodeURIComponent('Пример')] = searchResult(first);
  entries[first] = page(1, 2020, 101);
  entries[site + '/playls2/public/trans/101/plist.txt?time=123'] = [{ id: '1', file: '//cdn.test/translated.mp4' }];
  const client = fixtureClient(entries);
  assert.equal((await provider.resolve(meta, 1, 1, {}, client))[0].url, 'https://cdn.test/translated.mp4');
  assert.equal(client.calls.length, 4);
});

test('resolve preserves site blocking and skips an individually unavailable translation', async () => {
  const entries = {};
  entries[site + '/search?q=The%20Example'] = searchResult(first);
  entries[first] = page(1, 2020, 101);
  const blocked = new Error('Blocked'); blocked.siteBlocked = true;
  entries[site + '/playls2/public/trans/101/plist.txt?time=123'] = blocked;
  await assert.rejects(provider.resolve(meta, 1, 1, {}, fixtureClient(entries)), error => error === blocked);
  entries[site + '/playls2/public/trans/101/plist.txt?time=123'] = new Error('Not available');
  assert.deepEqual(await provider.resolve(meta, 1, 1, {}, fixtureClient(entries)), []);
});

test('movies, specials and invalid episode numbers make no Seasonvar requests', async () => {
  const client = fixtureClient({});
  assert.deepEqual(await provider.resolve({ type: 'movie', title: 'Example' }, 1, 1, {}, client), []);
  assert.deepEqual(await provider.resolve(meta, 0, 1, {}, client), []);
  assert.deepEqual(await provider.resolve(meta, 1, 1.5, {}, client), []);
  assert.deepEqual(await provider.resolve(meta, Infinity, 1, {}, client), []);
  assert.equal(client.calls.length, 0);
});
