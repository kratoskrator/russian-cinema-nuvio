'use strict';
var test = require('node:test');
var assert = require('node:assert/strict');
var hdvb = require('../src/hdvb');
var movie = { type: 'movie', title: 'Интерстеллар', originalTitle: 'Interstellar', year: 2014, imdb: 'tt0816692' };
var series = { type: 'tv', title: 'Во все тяжкие', originalTitle: 'Breaking Bad', year: 2008, imdb: 'tt0903747' };
var TOKEN = 'my-own-approved-partner-token';
var IFRAME = 'https://player.example/movie/test';
var CONFIG = '<script>var player = {"href":"cdn.example","key":"ephemeral-player-csrf","file":"/playlist/root.txt"};</script>';
function item(meta) {
  return { type: meta.type === 'tv' ? 'serial' : 'movie', title_ru: meta.title, title_en: meta.originalTitle, year: meta.year, imdb_id: meta.imdb, translator: 'LostFilm', iframe_url: IFRAME };
}
function fixture(meta, playlist, final) {
  var calls = [];
  return { calls: calls, request: function (url, options) {
    calls.push({ url: url, options: options });
    if (/\/api\/videos\.json\?/.test(url)) return Promise.resolve([item(meta)]);
    if (url === IFRAME) return Promise.resolve(CONFIG);
    if (/\/playlist\/root\.txt$/.test(url)) return Promise.resolve(playlist);
    return Promise.resolve(final);
  } };
}

test('HDVB makes no requests without the user approved partner token', async function () {
  var client = fixture(movie, '', '');
  assert.deepEqual(await hdvb.resolve(movie, null, null, {}, client), []);
  assert.equal(client.calls.length, 0);
});

test('HDVB rejects insecure or credential-bearing partner API origins before request', async function () {
  for (var api of ['http://apivb.com', 'https://user:pass@apivb.com', 'https://apivb.com/?token=shared']) {
    var client = fixture(movie, '', '');
    await assert.rejects(hdvb.resolve(movie, null, null, { hdvbToken: TOKEN, hdvbApi: api }, client), /HTTPS/);
    assert.equal(client.calls.length, 0);
  }
});

test('HDVB rejects movie/series collisions, wrong remakes, and explicit IMDb conflicts', function () {
  var entry = item(movie);
  delete entry.imdb_id;
  assert.ok(hdvb.matchScore(entry, movie) > 0);
  assert.equal(hdvb.matchScore(Object.assign({}, entry, { year: 2023 }), movie), -1);
  assert.equal(hdvb.matchScore(Object.assign({}, entry, { type: 'serial' }), movie), -1);
  assert.equal(hdvb.matchScore(Object.assign({}, entry, { imdb_id: 'tt1234567' }), movie), -1);
});

test('HDVB resolves ordinary movie player configuration and exposes HLS variants', async function () {
  var client = fixture(movie, '[720p]https://media.example/720/index.m3u8,[1080p]https://media.example/1080/index.m3u8');
  var streams = await hdvb.resolve(movie, null, null, { hdvbToken: TOKEN }, client);
  assert.equal(client.calls.length, 3);
  assert.deepEqual(streams.map(function (stream) { return stream.quality; }), ['720p', '1080p']);
  assert.equal(streams[0].type, 'hls');
  assert.deepEqual(streams[0].headers, { Referer: 'https://player.example/', Origin: 'https://player.example' });
});

test('HDVB selects season/episode/voice exactly, independent of playlist order', async function () {
  var list = [{ id: '2', folder: [{ episode: '2', folder: [{ title: 'LostFilm', file: '/playlist/wrong.txt' }] }, { episode: '1', folder: [{ title: 'Dub', file: '/playlist/other.txt' }, { title: 'LostFilm', file: '/playlist/correct.txt' }] }] }];
  var client = fixture(series, JSON.stringify(list), 'https://media.example/correct/index.m3u8');
  var streams = await hdvb.resolve(series, 2, 1, { hdvbToken: TOKEN }, client);
  assert.equal(streams.length, 1);
  assert.equal(client.calls.length, 4);
  assert.match(client.calls[3].url, /\/correct\.txt$/);
  assert.equal(streams[0].quality, 'Auto');
});

test('HDVB never substitutes first episode or translation when requested entry is missing', async function () {
  var list = [{ id: 1, folder: [{ episode: 2, folder: [{ title: 'LostFilm', file: 'wrong' }] }] }];
  var client = fixture(series, JSON.stringify(list), 'https://media.example/wrong/index.m3u8');
  assert.deepEqual(await hdvb.resolve(series, 1, 1, { hdvbToken: TOKEN }, client), []);
  assert.equal(client.calls.length, 3);
  assert.equal(hdvb.selectedEpisode([{ id: 1, folder: [{ episode: 1, folder: [{ title: 'Other', file: 'wrong' }] }] }], 1, 1, 'LostFilm'), null);
});

test('HDVB scopes account token to partner API and ephemeral CSRF key only to playlist POST', async function () {
  var client = fixture(movie, 'https://media.example/1080/index.m3u8');
  var streams = await hdvb.resolve(movie, null, null, { hdvbToken: TOKEN }, client);
  assert.match(client.calls[0].url, new RegExp('token=' + TOKEN));
  assert.equal(client.calls[0].options.sensitive, true);
  client.calls.slice(1).forEach(function (call) {
    assert.ok(!call.url.includes(TOKEN));
    assert.ok(!JSON.stringify(call.options).includes(TOKEN));
  });
  assert.equal(client.calls[2].options.headers['X-CSRF-Token'], 'ephemeral-player-csrf');
  assert.ok(!JSON.stringify(streams).includes(TOKEN));
  assert.ok(!JSON.stringify(streams).includes('ephemeral-player-csrf'));
});

test('HDVB follows only one extra movie playlist pointer', async function () {
  var client = fixture(movie, '{"file":"/playlist/next.txt"}', 'https://media.example/1080/index.m3u8');
  assert.equal((await hdvb.resolve(movie, null, null, { hdvbToken: TOKEN }, client)).length, 1);
  assert.equal(client.calls.length, 4);
  var loop = fixture(movie, '{"file":"/playlist/root.txt"}', '');
  assert.deepEqual(await hdvb.resolve(movie, null, null, { hdvbToken: TOKEN }, loop), []);
  assert.equal(loop.calls.length, 4);
});

test('HDVB rejects malformed configuration and traversal/absolute playlist paths', function () {
  assert.equal(hdvb.playerConfig('{"href":"evil.example/path","key":"x","file":"x"}', IFRAME), null);
  var config = hdvb.playerConfig(CONFIG, IFRAME);
  assert.equal(hdvb.playlistUrl('https://evil.example/steal', config), '');
  assert.equal(hdvb.playlistUrl('../steal', config), '');
  assert.equal(hdvb.playlistUrl('/playlist/good/key.txt', config), 'https://vid11.cdn.example/playlist/good/key.txt');
});

test('HDVB rejects insecure, unrelated, and account-token CDN values', function () {
  assert.deepEqual(hdvb.mediaUrls('http://media.example/index.m3u8', TOKEN, 'HDVB', {}), []);
  assert.deepEqual(hdvb.mediaUrls('https://media.example/video.mp4', TOKEN, 'HDVB', {}), []);
  assert.deepEqual(hdvb.mediaUrls('https://media.example/' + TOKEN + '/index.m3u8', TOKEN, 'HDVB', {}), []);
  assert.deepEqual(hdvb.mediaUrls('https://media.example/index.m3u8?access_token=secret', TOKEN, 'HDVB', {}), []);
});

test('HDVB sanitizes API and player failures without echoing tokens', async function () {
  var client = { request: function () { return Promise.reject(new Error('Denied ' + TOKEN)); } };
  await assert.rejects(hdvb.resolve(movie, null, null, { hdvbToken: TOKEN }, client), function (error) {
    return error.providerSafe && !error.message.includes(TOKEN) && /Partner API\/player request failed/.test(error.message);
  });
});
