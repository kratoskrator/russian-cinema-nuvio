'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const media=require('../src/media');
test('DASH uses real representation dimensions and codec declarations',()=>{
 const result=media.dash('<MPD><Period><AdaptationSet codecs="av01.0.08M.08"><Representation width="3840" height="2160"/></AdaptationSet><AdaptationSet codecs="opus"><Representation/></AdaptationSet></Period></MPD>');
 assert.equal(result.quality,'2160p');assert.equal(result.codecSummary,'AV1 + Opus');
});
test('DASH accepts adaptation dimensions inherited by a representation and ignores comments',()=>{
 const result=media.dash('<MPD><!--<Representation height="4320"/>--><Period><AdaptationSet width="1920" height="1080" codecs="avc1.640028"><Representation id="video"/></AdaptationSet></Period></MPD>');
 assert.equal(result.quality,'1080p');assert.equal(result.codecSummary,'H.264');
});
test('DASH representation dimensions take priority over the adaptation maximum',()=>{
 const result=media.dash('<MPD><Period><AdaptationSet maxWidth="3840" maxHeight="2160" codecs="vp09.00.40.08"><Representation width="1920" height="1080"/></AdaptationSet><AdaptationSet codecs="opus"><Representation/></AdaptationSet></Period></MPD>');
 assert.equal(result.quality,'1080p');assert.equal(result.width,1920);assert.equal(result.codecSummary,'VP9 + Opus');
});
test('protected, truncated, audio-only and HTML responses do not become DASH streams',()=>{
 for(const body of ['<html>Not video</html>','<MPD><Period><Representation height="1080"/>','<MPD><Period><Representation codecs="opus"/></Period></MPD>','<MPD><Period><ContentProtection/><Representation height="1080"/></Period></MPD>'])assert.equal(media.dash(body),null);
});
test('HLS master reports actual highest resolution and codec choices',()=>{
 const result=media.hls('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=100000,RESOLUTION=1280x720,CODECS="avc1.64001f,mp4a.40.2"\n720.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=200000,RESOLUTION=1920x1080,CODECS="avc1.640028,mp4a.40.2"\n1080.m3u8');
 assert.equal(result.quality,'1080p');assert.equal(result.codecSummary,'H.264 + AAC');
});
test('ordinary AES-128 identity HLS stays playable while DRM key formats are omitted',()=>{
 for(const format of ['identity','"identity"',"'identity'"]){
  assert.ok(media.hls('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,KEYFORMAT='+format+',URI="key"\n#EXTINF:10,\nvideo.ts\n#EXT-X-ENDLIST'));
 }
 for(const key of ['METHOD=SAMPLE-AES,URI="key"','METHOD=SAMPLE-AES-CTR,URI="key"','METHOD=AES-128,KEYFORMAT="com.apple.streamingkeydelivery",URI="key"'])assert.equal(media.hls('#EXTM3U\n#EXT-X-KEY:'+key+'\n#EXTINF:10,\nvideo.ts'),null);
});
test('empty or malformed M3U headers are excluded without requiring a guessed quality',()=>{
 assert.equal(media.hls('#EXTM3U\n<html>expired</html>'),null);
 assert.equal(media.hls('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000'),null);
 assert.equal(media.hls('#EXTM3U\n#EXTINF:10,\nsegment.ts\n#EXT-X-ENDLIST').quality,'');
});
