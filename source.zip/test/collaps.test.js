'use strict';
var test = require('node:test');
var assert = require('node:assert/strict');
var collaps = require('../src/collaps');
var SITE = 'https://api.luxembd.ws';
var movie = { type: 'movie', imdb: 'tt0816692', title: 'Interstellar' };
var series = { type: 'tv', imdb: 'tt0903747', title: 'Breaking Bad' };

function source(suffix) {
  suffix = suffix || '';
  return {
    dash: 'https://cdn.example/' + suffix + 'video.mpd?token=a%2Bb%3D',
    dasha: 'https://cdn.example/' + suffix + 'alternate.mpd',
    hls: 'https://cdn.example/' + suffix + 'master.m3u8',
    audio: { names: ['Рус. Дублированный', 'Eng.Original'], order: [0, 1] },
    cc: [{ url: 'https://cdn.example/ru.vtt', name: 'Рус. полные' }, { url: 'https://cdn.example/en.vtt', name: 'Eng. full' }]
  };
}
function jsObject(value) {
  return '{' + Object.keys(value).map(function (name) { return name + ':' + JSON.stringify(value[name]); }).join(',') + '}';
}
function page(body) { return '<script data-name="mk">makePlayer({' + body + '});</script>'; }
function moviePage(entry) { return page('blocked:false,source:' + jsObject(entry || source())); }
function seriesPage(seasons) { return page('playlist:{current:{season:9,episode:"99"},seasons:' + JSON.stringify(seasons) + '}'); }
function seasons() {
  var first = source('s1e1-'); first.episode = '1';
  var second = source('s1e2-'); second.episode = '2';
  return [{ season: 1, blocked: false, episodes: [first, second] }];
}
function parse(html, meta, season, episode) { return collaps.candidates(html, meta || movie, season || 1, episode || 1, SITE); }

test('extracts intact DASH and HLS masters with published audio and subtitle labels', function () {
  var entry = source(), items = parse(moviePage(entry));
  assert.deepEqual(items.map(function (item) { return item.type; }), ['dash', 'dash', 'hls']);
  assert.equal(items[0].url, entry.dash);
  assert.equal(items[0].quality, undefined);
  assert.deepEqual(items[0].audio, entry.audio.names);
  assert.deepEqual(items[0].subtitles.map(function (item) { return item.lang; }), ['ru', 'en']);
  assert.equal(items[0].headers.Referer, SITE + '/');
  assert.equal(items[0].headers.Origin, SITE);
  assert.equal(Object.keys(items[0].headers).some(function (key) { return /authorization|cookie/i.test(key); }), false);
});

test('selects the exact requested episode instead of the player default or list position', function () {
  var items = parse(seriesPage(seasons()), series, 1, 2);
  assert.equal(items.length, 3);
  assert.match(items[0].url, /s1e2-video\.mpd/);
  assert.deepEqual(parse(seriesPage(seasons()), series, 1, 3), []);
  assert.deepEqual(parse(seriesPage(seasons()), series, 2, 1), []);
});

test('supports explicitly published specials without substituting season one', function () {
  var episode = source('special-'); episode.episode = '1';
  var html = seriesPage([{ season: 0, episodes: [episode] }]);
  assert.match(collaps.candidates(html, series, 0, 1, SITE)[0].url, /special-video/);
  assert.deepEqual(collaps.candidates(html, series, 1, 1, SITE), []);
});

test('rejects ambiguous duplicate seasons and episode numbers', function () {
  var list = seasons(); list.push(list[0]);
  assert.deepEqual(parse(seriesPage(list), series), []);
  list = seasons(); list[0].episodes.push(list[0].episodes[0]);
  assert.deepEqual(parse(seriesPage(list), series), []);
});

test('honors blocked movie, season and episode flags', function () {
  assert.deepEqual(parse(moviePage().replace('blocked:false', 'blocked:true')), []);
  var list = seasons(); list[0].blocked = true;
  assert.deepEqual(parse(seriesPage(list), series), []);
  list = seasons(); list[0].episodes[0].blocked = true;
  assert.deepEqual(parse(seriesPage(list), series), []);
  var entry = source(); entry.blocked = true;
  assert.deepEqual(parse(moviePage(entry)), []);
});

test('never treats movie sources as a series episode or a series playlist as a movie', function () {
  assert.deepEqual(parse(moviePage(), series), []);
  assert.deepEqual(parse(seriesPage(seasons()), movie), []);
});

test('ignores unrelated scripts and rejects multiple competing player-data sections', function () {
  var unrelated = '<script>makePlayer({source:{dash:"https://ad.example/ad.mpd"}});</script>';
  assert.equal(parse(unrelated + moviePage())[0].url, source().dash);
  assert.deepEqual(parse(unrelated), []);
  assert.deepEqual(parse(moviePage() + moviePage()), []);
});

test('parses surrounding functions as inert syntax and never executes a source expression', function () {
  var html = page('source:' + jsObject(source()) + ',p2p:{tracker:function(){var x="},[]";/* ignored } */return x;}}');
  assert.equal(parse(html).length, 3);
  globalThis.collapsCodeRan = false;
  assert.deepEqual(parse(page('source:{dash:(function(){globalThis.collapsCodeRan=true;return "https://cdn.example/v.mpd";})()}')), []);
  assert.equal(globalThis.collapsCodeRan, false);
  delete globalThis.collapsCodeRan;
});

test('rejects incomplete, malformed and duplicate player data', function () {
  assert.deepEqual(parse(moviePage().replace('});</script>', ');</script>')), []);
  assert.deepEqual(parse(page('source:' + jsObject(source()) + ',source:' + jsObject(source()))), []);
  assert.deepEqual(parse(page('playlist:{seasons:[notJSON]}'), series), []);
  assert.deepEqual(parse(page('source:{dash:"https://cdn.example/v.mpd\\q"}')), []);
  assert.deepEqual(parse(page('source:{["dash"]:"https://cdn.example/v.mpd"}')), []);
});

test('validates playback URLs without decoding or rewriting signed query tokens', function () {
  var good = source().dash;
  assert.equal(collaps.safeUrl(good, 'mpd'), good);
  [
    'javascript:alert(1)', 'file:///x.mpd', '//cdn.example/x.mpd',
    'https://user:pass@cdn.example/x.mpd', 'https://cdn.example:70000/x.mpd',
    'https://cdn.example/x.mpd\n', 'https://cdn.example\\evil/x.mpd',
    'https://cdn.example/x.mpd?x=%0aInjected', 'https://cdn.example/x.mpd?x=%5c',
    'https://cdn.example/x.mpd?x=%GG', 'https://cdn.example/x.mpd?x=%',
    'https://cdn.example/path?next=video.mpd', 'https://cdn.example/clip.mp4'
  ].forEach(function (url) { assert.equal(collaps.safeUrl(url, 'mpd'), '', url); });
});

test('deduplicates masters and filters unsafe or duplicate subtitle URLs', function () {
  var entry = source(); entry.dasha = entry.dash;
  entry.cc.push(entry.cc[0], { url: 'javascript:alert(1)', name: 'Рус.' }, { url: 'https://user:pass@cdn.example/a.vtt', name: 'English' });
  assert.equal(parse(moviePage(entry)).length, 2);
  assert.equal(parse(moviePage(entry))[0].subtitles.length, 2);
});

test('bounds page size, season count, episode count, audio and subtitle lists', function () {
  assert.equal(collaps.playerData(new Array(1024 * 1024 + 2).join('x')), null);
  var list = new Array(101).fill({ season: 9, episodes: [] });
  assert.deepEqual(parse(seriesPage(list), series), []);
  assert.deepEqual(parse(seriesPage([{ season: 1, episodes: new Array(1001).fill({ episode: '1' }) }]), series), []);
  var entry = source(); entry.audio.names = new Array(100).fill('Voice');
  entry.cc = new Array(100).fill(null).map(function (_, index) { return { url: 'https://cdn.example/sub' + index + '.vtt', name: 'Рус.' }; });
  var items = parse(moviePage(entry));
  assert.ok(items.length <= 8);
  assert.equal(items[0].audio.length, 32);
  assert.equal(items[0].subtitles.length, 16);
});

test('resolve uses a single anonymous public IMDb request with the configured HTTPS site', function () {
  var calls = [], site = 'https://embed.example';
  return collaps.resolve(series, 1, 2, { collapsSite: site, deadline: Date.now() + 10000 }, {
    request: function (url, options) { calls.push({ url: url, options: options }); return Promise.resolve(seriesPage(seasons())); }
  }).then(function (items) {
    assert.equal(calls.length, 1);
    assert.equal(calls[0].url, site + '/embed/imdb/tt0903747');
    assert.equal(calls[0].options.referer, site + '/');
    assert.ok(calls[0].options.timeout <= 12000);
    assert.equal(calls[0].options.bearer, undefined);
    assert.equal(items[0].headers.Origin, site);
    assert.match(items[0].url, /s1e2-video/);
  });
});

test('resolve skips invalid identifiers, invalid episodes and expired lookups', function () {
  var called = false, client = { request: function () { called = true; return Promise.resolve(moviePage()); } };
  return Promise.all([
    collaps.resolve({ type: 'movie', imdb: 'tt1/../../other' }, null, null, {}, client),
    collaps.resolve({ type: 'movie' }, null, null, {}, client),
    collaps.resolve(series, 1, 0, {}, client),
    collaps.resolve(series, -1, 1, {}, client),
    collaps.resolve(series, 1.2, 1, {}, client),
    collaps.resolve(movie, null, null, { deadline: Date.now() - 1 }, client)
  ]).then(function (results) {
    results.forEach(function (result) { assert.deepEqual(result, []); });
    assert.equal(called, false);
  });
});

test('resolve propagates a blocked response for the provider-level error handler', function () {
  var error = new Error('Blocked'); error.siteBlocked = true;
  return assert.rejects(collaps.resolve(movie, null, null, {}, { request: function () { return Promise.reject(error); } }), function (actual) { return actual === error; });
});
