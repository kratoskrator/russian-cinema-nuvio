'use strict';
var test = require('node:test');
var assert = require('node:assert/strict');
var filmix = require('../src/filmix');

var movie = { type: 'movie', title: 'Интерстеллар', originalTitle: 'Interstellar', year: 2014, imdb: 'tt0816692' };
var series = { type: 'tv', title: 'Во все тяжкие', originalTitle: 'Breaking Bad', year: 2008, imdb: 'tt0903747' };
function result(id, title, year, section) {
  return { id: id, title: title, original_title: title, year: year, section: section || 0 };
}
function postResult(id, meta, playerLinks) {
  return { id: id, title: meta.title, original_title: meta.originalTitle, year: meta.year, section: meta.type === 'tv' ? 7 : 0, player_links: playerLinks };
}
function requestFixture(search, post) {
  var calls = [];
  return {
    calls: calls,
    request: function (url, options) {
      calls.push({ url: url, options: options });
      return Promise.resolve(/\/search\?/.test(url) ? search : post);
    }
  };
}

test('matches original titles and selects the matching year over a remake', function () {
  var items = [result(1, 'Interstellar', 2024), result(2, 'The Science of Interstellar', 2014), result(3, 'Interstellar', 2014)];
  assert.equal(filmix.selectResult(items, movie).id, 3);
  assert.equal(filmix.matchScore(items[0], movie), -1);
});

test('does not confuse a movie with a series sharing its title', function () {
  var items = [result(1, 'Breaking Bad', 2008, 0), result(2, 'Breaking Bad', 2008, 7)];
  assert.equal(filmix.selectResult(items, series).id, 2);
  assert.equal(filmix.matchScore(items[0], series), -1);
});

test('recognizes noncanonical series sections only with actual series metadata', function () {
  var item = result(1, 'Breaking Bad', 2008, 93);
  assert.equal(filmix.matchScore(item, series), -1);
  item.serial_stats = { status: '1' };
  assert.ok(filmix.matchScore(item, series) > 0);
});

test('an explicit IMDb match identifies translated titles without fuzzy matching', function () {
  var item = result(3, 'A different localized title', 2000);
  item.imdb_id = movie.imdb;
  assert.ok(filmix.matchScore(item, movie) >= 200);
  delete item.imdb_id;
  assert.equal(filmix.matchScore(item, movie), -1);
});

test('expands Filmix bracket quality placeholders to a genuine guest quality', function () {
  var media = filmix.mediaLink('https://cdn.example/movie_[2160,1080,720,480,360].mp4');
  assert.equal(media.url, 'https://cdn.example/movie_480.mp4');
  assert.equal(media.quality, '480p');
  assert.equal(media.type, 'mp4');
  assert.equal(filmix.mediaLink('https://cdn.example/movie_[2160,1080,720].mp4'), null);
});

test('expands episode placeholders from declared qualities and rejects premium-only direct files', function () {
  var media = filmix.mediaLink('https://cdn.example/s01e03_%s.mp4', [1080, 480, 720]);
  assert.equal(media.url, 'https://cdn.example/s01e03_480.mp4');
  assert.equal(filmix.mediaLink('https://cdn.example/movie_1080.mp4', [480, 1080]), null);
  assert.equal(filmix.mediaLink('https://cdn.example/movie.mp4'), null);
  assert.equal(filmix.mediaLink('javascript:alert(1)', [480]), null);
  assert.equal(filmix.mediaLink('https://user:secret@cdn.example/movie_480.mp4'), null);
});

test('selects exact season and episode keys and never substitutes another episode', function () {
  var post = postResult(2, series, { playlist: {
    '1': { Dub: { '1': { link: 'https://cdn.example/s01e01_%s.mp4', qualities: [480] } } },
    '2': { Dub: { '3': { link: 'https://cdn.example/s02e03_%s.mp4', qualities: [480] } } }
  } });
  assert.equal(filmix.candidates(post, series, 2, 3)[0].url, 'https://cdn.example/s02e03_480.mp4');
  assert.deepEqual(filmix.candidates(post, series, 2, 1), []);
  assert.deepEqual(filmix.candidates(post, series, 3, 3), []);
});

test('supports array episodes with one-based episode numbers', function () {
  var post = postResult(2, series, { playlist: { '1': { Dub: [
    { link: 'https://cdn.example/s01e01_%s.mp4', qualities: [480] },
    { link: 'https://cdn.example/s01e02_%s.mp4', qualities: [480] }
  ] } } });
  assert.equal(filmix.candidates(post, series, 1, 2)[0].url, 'https://cdn.example/s01e02_480.mp4');
});

test('ignores trailers, deduplicates playback URLs, and bounds available voiceovers', function () {
  var videos = [];
  for (var i = 0; i < 15; i++) videos.push({ translation: 'Dub ' + i, link: 'https://cdn.example/movie' + i + '_[720,480].mp4' });
  videos.unshift(videos[0]);
  var candidates = filmix.candidates(postResult(1, movie, {
    movie: videos, trailer: [{ link: 'https://cdn.example/trailer_480.mp4' }]
  }), movie);
  assert.equal(candidates.length, 8);
  assert.equal(new Set(candidates.map(function (v) { return v.url; })).size, 8);
  assert.ok(candidates.every(function (v) { return v.quality === '480p' && !/trailer/.test(v.url); }));
});

test('uses a public guest client without account credentials or TMDB keys', async function () {
  var client = requestFixture([result(81482, 'Interstellar', 2014)], postResult(81482, movie, {
    movie: [{ translation: 'Дубляж', link: 'https://cdn.example/movie_[720,480].mp4' }]
  }));
  var streams = await filmix.resolve(movie, null, null, { key: 'PRIVATE_TMDB_KEY', filmixSite: 'https://filmix.gg' }, client);
  assert.equal(streams.length, 1);
  assert.equal(client.calls.length, 2);
  client.calls.forEach(function (call) {
    assert.ok(call.url.indexOf('http://filmixapp.cyou/api/v2/') === 0);
    assert.ok(/user_dev_id=[a-f0-9]{16}/.test(call.url));
    assert.equal(call.options.headers['User-Agent'], 'okhttp/4.9.2');
    assert.equal(call.options.json, true);
    assert.ok(!/PRIVATE_TMDB_KEY|token|cookie|password/i.test(call.url + JSON.stringify(call.options)));
  });
  assert.equal(new URL(client.calls[0].url).searchParams.get('user_dev_id'), new URL(client.calls[1].url).searchParams.get('user_dev_id'));
  assert.deepEqual(streams[0].headers, { 'User-Agent': 'okhttp/4.9.2', Accept: '*/*' });
});

test('refuses to send an account token to the HTTP guest API', async function () {
  var client = requestFixture([], {});
  await assert.rejects(filmix.resolve(movie, null, null, { filmixToken: 'PRIVATE_ACCOUNT_TOKEN' }, client), /Account tokens are unavailable/);
  assert.equal(client.calls.length, 0);
});

test('rechecks the post identity and rejects a mismatching response', async function () {
  var client = requestFixture([result(81482, 'Interstellar', 2014)], postResult(999, movie, {
    movie: [{ link: 'https://cdn.example/movie_[480].mp4' }]
  }));
  assert.deepEqual(await filmix.resolve(movie, null, null, {}, client), []);
  client = requestFixture([result(81482, 'Interstellar', 2014)], postResult(81482, Object.assign({}, movie, { year: 2024 }), {
    movie: [{ link: 'https://cdn.example/movie_[480].mp4' }]
  }));
  assert.deepEqual(await filmix.resolve(movie, null, null, {}, client), []);
});

test('empty/locked player links produce no fabricated candidates', function () {
  assert.deepEqual(filmix.candidates(postResult(1, movie, { movie: [], playlist: [], trailer: [] }), movie), []);
  assert.deepEqual(filmix.candidates(postResult(1, series, { playlist: [] }), series, 1, 1), []);
});

test('stops invalid episode requests before any network call', async function () {
  var client = requestFixture([], {});
  assert.deepEqual(await filmix.resolve(series, -1, 1, {}, client), []);
  assert.deepEqual(await filmix.resolve(series, 1, 0, {}, client), []);
  assert.equal(client.calls.length, 0);
});
