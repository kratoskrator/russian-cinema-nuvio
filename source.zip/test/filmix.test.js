'use strict';
var test = require('node:test');
var assert = require('node:assert/strict');
var filmix = require('../src/filmix');

var movie = { type: 'movie', title: 'Интерстеллар', originalTitle: 'Interstellar', year: 2014, imdb: 'tt0816692' };
var series = { type: 'tv', title: 'Во все тяжкие', originalTitle: 'Breaking Bad', year: 2008, imdb: 'tt0903747' };
function result(id, title, year, section) {
  return { id: id, title: title, original_title: title, year: year, section: section || 0 };
}
function postResult(id, meta, playerLinks) {
  return { id: id, title: meta.title, original_title: meta.originalTitle, year: meta.year, section: meta.type === 'tv' ? 7 : 0, player_links: playerLinks };
}
function requestFixture(search, post) {
  var calls = [];
  return {
    calls: calls,
    request: function (url, options) {
      calls.push({ url: url, options: options });
      return Promise.resolve(/\/search\?/.test(url) ? search : post);
    }
  };
}

test('matches original titles and selects the matching year over a remake', function () {
  var items = [result(1, 'Interstellar', 2024), result(2, 'The Science of Interstellar', 2014), result(3, 'Interstellar', 2014)];
  assert.equal(filmix.selectResult(items, movie).id, 3);
  assert.equal(filmix.matchScore(items[0], movie), -1);
});

test('does not confuse a movie with a series sharing its title', function () {
  var items = [result(1, 'Breaking Bad', 2008, 0), result(2, 'Breaking Bad', 2008, 7)];
  assert.equal(filmix.selectResult(items, series).id, 2);
  assert.equal(filmix.matchScore(items[0], series), -1);
});

test('recognizes noncanonical series sections only with actual series metadata', function () {
  var item = result(1, 'Breaking Bad', 2008, 93);
  assert.equal(filmix.matchScore(item, series), -1);
  item.serial_stats = { status: '1' };
  assert.ok(filmix.matchScore(item, series) > 0);
});

test('an explicit IMDb match identifies translated titles without fuzzy matching', function () {
  var item = result(3, 'A different localized title', 2000);
  item.imdb_id = movie.imdb;
  assert.ok(filmix.matchScore(item, movie) >= 200);
  delete item.imdb_id;
  assert.equal(filmix.matchScore(item, movie), -1);
});

test('expands Filmix bracket quality placeholders to a genuine guest quality', function () {
  var media = filmix.mediaLink('https://cdn.example/movie_[2160,1080,720,480,360].mp4');
  assert.equal(media.url, 'https://cdn.example/movie_480.mp4');
  assert.equal(media.quality, '480p');
  assert.equal(media.type, 'mp4');
  assert.equal(filmix.mediaLink('https://cdn.example/movie_[2160,1080,720].mp4'), null);
});

test('expands episode placeholders from declared qualities and rejects premium-only direct files', function () {
  var media = filmix.mediaLink('https://cdn.example/s01e03_%s.mp4', [1080, 480, 720]);
  assert.equal(media.url, 'https://cdn.example/s01e03_480.mp4');
  assert.equal(filmix.mediaLink('https://cdn.example/movie_1080.mp4', [480, 1080]), null);
  assert.equal(filmix.mediaLink('https://cdn.example/movie.mp4'), null);
  assert.equal(filmix.mediaLink('javascript:alert(1)', [480]), null);
  assert.equal(filmix.mediaLink('https://user:secret@cdn.example/movie_480.mp4'), null);
});

test('selects exact season and episode keys and never substitutes another episode', function () {
  var post = postResult(2, series, { playlist: {
    '1': { Dub: { '1': { link: 'https://cdn.example/s01e01_%s.mp4', qualities: [480] } } },
    '2': { Dub: { '3': { link: 'https://cdn.example/s02e03_%s.mp4', qualities: [480] } } }
  } });
  assert.equal(filmix.candidates(post, series, 2, 3)[0].url, 'https://cdn.example/s02e03_480.mp4');
  assert.deepEqual(filmix.candidates(post, series, 2, 1), []);
  assert.deepEqual(filmix.candidates(post, series, 3, 3), []);
});

test('supports array episodes with one-based episode numbers', function () {
  var post = postResult(2, series, { playlist: { '1': { Dub: [
    { link: 'https://cdn.example/s01e01_%s.mp4', qualities: [480] },
    { link: 'https://cdn.example/s01e02_%s.mp4', qualities: [480] }
  ] } } });
  assert.equal(filmix.candidates(post, series, 1, 2)[0].url, 'https://cdn.example/s01e02_480.mp4');
});

test('ignores trailers, deduplicates playback URLs, and bounds available voiceovers', function () {
  var videos = [];
  for (var i = 0; i < 15; i++) videos.push({ translation: 'Dub ' + i, link: 'https://cdn.example/movie' + i + '_[720,480].mp4' });
  videos.unshift(videos[0]);
  var candidates = filmix.candidates(postResult(1, movie, {
    movie: videos, trailer: [{ link: 'https://cdn.example/trailer_480.mp4' }]
  }), movie);
  assert.equal(candidates.length, 8);
  assert.equal(new Set(candidates.map(function (v) { return v.url; })).size, 8);
  assert.ok(candidates.every(function (v) { return v.quality === '480p' && !/trailer/.test(v.url); }));
});

test('uses a public guest client without account credentials or TMDB keys', async function () {
  var client = requestFixture([result(81482, 'Interstellar', 2014)], postResult(81482, movie, {
    movie: [{ translation: 'Дубляж', link: 'https://cdn.example/movie_[720,480].mp4' }]
  }));
  var streams = await filmix.resolve(movie, null, null, { key: 'PRIVATE_TMDB_KEY', filmixSite: 'https://filmix.gg' }, client);
  assert.equal(streams.length, 1);
  assert.equal(client.calls.length, 2);
  client.calls.forEach(function (call) {
    assert.ok(call.url.indexOf('http://filmixapp.cyou/api/v2/') === 0);
    assert.ok(/user_dev_id=[a-f0-9]{16}/.test(call.url));
    assert.equal(call.options.headers['User-Agent'], 'okhttp/4.9.2');
    assert.equal(call.options.json, true);
    assert.ok(!/PRIVATE_TMDB_KEY|token|cookie|password/i.test(call.url + JSON.stringify(call.options)));
  });
  assert.equal(new URL(client.calls[0].url).searchParams.get('user_dev_id'), new URL(client.calls[1].url).searchParams.get('user_dev_id'));
  assert.deepEqual(streams[0].headers, { 'User-Agent': 'okhttp/4.9.2', Accept: '*/*' });
});

test('refuses to send an account token to the HTTP guest API', async function () {
  var client = requestFixture([], {});
  await assert.rejects(filmix.resolve(movie, null, null, { filmixToken: 'PRIVATE_ACCOUNT_TOKEN' }, client), /verified HTTPS mobile API/);
  assert.equal(client.calls.length, 0);
});

test('does not silently fall back to guest access for unsupported account settings', async function () {
  var settings = [
    { filmixUsername: 'PRIVATE_LOGIN' },
    { filmixPassword: 'PRIVATE_PASSWORD' },
    { filmixToken: 'PRIVATE_TOKEN', filmixApi: 'http://filmixapp.cyou/api/v2' },
    { filmixToken: 'PRIVATE_TOKEN', filmixApi: 'https://unverified.example/api/v2' },
    { filmixApi: 'https://api.filmix.tv/api-fx' }
  ];
  for (var i = 0; i < settings.length; i++) {
    var client = requestFixture([], {});
    await assert.rejects(filmix.resolve(movie, null, null, settings[i], client), function (error) {
      assert.equal(error.providerSafe, true);
      assert.ok(!/PRIVATE_|unverified\.example/.test(error.message));
      return /Guest access is limited to 480p/.test(error.message);
    });
    assert.equal(client.calls.length, 0);
  }
});

test('describes guest limits and the separate duration-verified FilmixTV HLS mode', function () {
  assert.equal(filmix.capabilities.guestMaxQuality, 480);
  assert.equal(filmix.capabilities.accountAvailable, false);
  assert.equal(filmix.capabilities.accountImplemented, true);
  assert.match(filmix.capabilities.accountMessage, /redirects can forward its device hash/);
  assert.match(filmix.capabilities.accountType, /HLS with runtime verification/);
  var post = postResult(81482, movie, { movie: [
    { translation: 'Pro+', link: 'https://cdn.example/movie_[2160,1440,1080].mp4' }
  ] });
  assert.deepEqual(filmix.candidates(post, movie), []);
});

var tvAccount = { filmixTvToken: 'PRIVATE_ACCOUNT_ACCESS_TOKEN', filmixTvHash: '0123456789abcdef0123456789abcdef' };
function vod(seconds, endList) {
  var body = '#EXTM3U\n#EXT-X-TARGETDURATION:600\n';
  for (var i = 0; seconds > 0; i++) {
    var duration = Math.min(seconds, 600);
    body += '#EXTINF:' + duration + ',\nsegment-' + i + '.ts\n';
    seconds -= duration;
  }
  return body + (endList === false ? '' : '#EXT-X-ENDLIST\n');
}
function accountFixture(meta, data, playlists) {
  var calls = [];
  return {
    calls: calls,
    filmixTvRedirectSafe: true,
    request: function (url, options) {
      calls.push({ url: url, options: options });
      if (/^http:\/\/filmixapp\.cyou\//.test(url)) {
        return Promise.resolve(/\/search\?/.test(url) ? [result(111, meta.originalTitle, meta.year, meta.type === 'tv' ? 7 : 0)] : postResult(111, meta, {
          movie: [{ translation: 'Guest dub', link: 'https://guest.example/movie_[480].mp4' }],
          playlist: { '1': { Dub: { '1': { link: 'https://guest.example/s01e01_%s.mp4', qualities: [480] } } } }
        }));
      }
      if (/^https:\/\/api\.filmix\.tv\/api-fx\/list\?/.test(url)) {
        return Promise.resolve({ finalUrl: url, body: { items: [{ id: 222, title: meta.title, original_name: meta.originalTitle, year: meta.year, last_season: meta.type === 'tv' ? 5 : null, last_episode: meta.type === 'tv' ? 16 : null }] } });
      }
      if (/^https:\/\/api\.filmix\.tv\/api-fx\/post\/222\/video-links$/.test(url)) return Promise.resolve({ finalUrl: url, body: data });
      if (Object.prototype.hasOwnProperty.call(playlists || {}, url)) {
        var response = playlists[url];
        if (response instanceof Error) return Promise.reject(response);
        return Promise.resolve(typeof response === 'string' ? { finalUrl: url, body: response } : response);
      }
      return Promise.reject(new Error('Unexpected request: ' + url));
    }
  };
}

test('FilmixTV sends an own account token only to its fixed HTTPS API and checks full HLS duration', async function () {
  var meta = Object.assign({}, movie, { runtimeSeconds: 3600 });
  var url = 'https://cdn.example/movie-1080/index.m3u8';
  var uhd = 'https://cdn.example/movie-2160/index.m3u8';
  var client = accountFixture(meta, [{ voiceover: 'Дубляж', files: [{ quality: 1080, url: url }, { quality: 2160, url: uhd }] }], { [url]: vod(3600), [uhd]: vod(3600) });
  var streams = await filmix.resolve(meta, null, null, tvAccount, client);
  assert.equal(streams.length, 3);
  assert.equal(streams[0].quality, '2160p');
  assert.equal(streams[0].qualityVerified, false);
  assert.equal(streams[0].qualitySource, 'api');
  assert.equal(streams[0].durationVerified, true);
  assert.match(streams[0].title, /source-labelled 2160p/);
  assert.equal(streams[1].quality, '1080p');
  assert.equal(streams[2].quality, '480p');
  client.calls.forEach(function (call) {
    assert.ok(!/PRIVATE_ACCOUNT/.test(call.url));
    if (/^https:\/\/api\.filmix\.tv\/api-fx\//.test(call.url)) {
      assert.equal(call.options.bearer, tvAccount.filmixTvToken);
      assert.equal(call.options.headers.hash, tvAccount.filmixTvHash);
      assert.equal(call.options.redirect, 'error');
    } else {
      assert.ok(!/PRIVATE_ACCOUNT|0123456789abcdef|bearer|authorization|hash/i.test(JSON.stringify(call.options)));
    }
  });
  assert.deepEqual(streams[0].headers, { 'User-Agent': 'okhttp/4.9.2', Accept: '*/*' });
});

test('current runtimes cannot send a FilmixTV hash even with supplied account settings', async function () {
  var meta = Object.assign({}, movie, { runtimeSeconds: 3600 });
  var client = accountFixture(meta, [], {});
  delete client.filmixTvRedirectSafe;
  var cfg = Object.assign({}, tvAccount, { filmixTvRedirectSafe: true });
  var streams = await filmix.resolve(meta, null, null, cfg, client);
  assert.equal(streams.length, 1);
  assert.equal(streams[0].quality, '480p');
  assert.ok(client.calls.every(function (call) { return /^http:\/\/filmixapp\.cyou\//.test(call.url); }));
  client.calls.forEach(function (call) {
    assert.ok(!/PRIVATE_ACCOUNT|0123456789abcdef|bearer|authorization|hash/i.test(JSON.stringify(call.options)));
  });
});

test('even a future safe client rejects account credentials embedded in CDN URLs', async function () {
  var meta = Object.assign({}, movie, { runtimeSeconds: 3600 });
  var urls = [
    'https://cdn.example/' + tvAccount.filmixTvToken + '/index.m3u8',
    'https://cdn.example/' + tvAccount.filmixTvHash + '/index.m3u8',
    'https://cdn.example/index.m3u8?access_token=private',
    'https://cdn.example/index.m3u8?%61pi_key=private',
    'https://cdn.example/index.m3u8?hash=private'
  ];
  for (var i = 0; i < urls.length; i++) {
    var client = accountFixture(meta, [{ voiceover: 'Dub', files: [{ quality: 1080, url: urls[i] }] }], {});
    var streams = await filmix.resolve(meta, null, null, tvAccount, client);
    assert.equal(streams.length, 1);
    assert.equal(streams[0].quality, '480p');
    assert.ok(!client.calls.some(function (call) { return /^https:\/\/cdn\.example/.test(call.url); }));
  }
  var normal = 'https://cdn.example/index.m3u8';
  var redirected = normal + '?user_dev_token=private';
  var redirectedClient = accountFixture(meta, [{ voiceover: 'Dub', files: [{ quality: 1080, url: normal }] }], {
    [normal]: { finalUrl: redirected, body: vod(3600) }
  });
  var redirectedStreams = await filmix.resolve(meta, null, null, tvAccount, redirectedClient);
  assert.ok(redirectedStreams.every(function (stream) { return !/user_dev_token/.test(stream.url); }));
});

test('FilmixTV rejects preview, live, DRM, malformed and redirected HTTP playlists while preserving guest', async function () {
  var meta = Object.assign({}, movie, { runtimeSeconds: 3600 });
  var url = 'https://cdn.example/movie-1080/index.m3u8';
  var cases = [vod(120), vod(3600, false), vod(3600).replace('#EXTM3U', '#EXTM3U\n#EXT-X-KEY:METHOD=SAMPLE-AES,URI="drm.key"'), '#EXTM3U\n#EXTINF:3600,\n#EXT-X-ENDLIST', { finalUrl: 'http://cdn.example/playlist.m3u8', body: vod(3600) }, new Error('PRIVATE_ACCOUNT_ACCESS_TOKEN rejected')];
  for (var i = 0; i < cases.length; i++) {
    var client = accountFixture(meta, [{ voiceover: 'Dub', files: [{ quality: 1080, url: url }] }], { [url]: cases[i] });
    var streams = await filmix.resolve(meta, null, null, tvAccount, client);
    assert.equal(streams.length, 1);
    assert.equal(streams[0].quality, '480p');
  }
});

test('FilmixTV prefers actual HLS master resolution and validates its selected media playlist', async function () {
  var meta = Object.assign({}, movie, { runtimeSeconds: 3600 });
  var url = 'https://cdn.example/master.m3u8';
  var client = accountFixture(meta, [{ voiceover: 'Dub', files: [{ quality: 2160, url: url }] }], {
    [url]: '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=2000000,RESOLUTION=1280x720\n720.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=6000000,RESOLUTION=1920x1080\n1080.m3u8\n',
    'https://cdn.example/1080.m3u8': vod(3600)
  });
  var streams = await filmix.resolve(meta, null, null, tvAccount, client);
  assert.equal(streams[0].url, 'https://cdn.example/1080.m3u8');
  assert.equal(streams[0].quality, '1080p');
  assert.equal(streams[0].qualityVerified, true);
  assert.equal(streams[0].qualitySource, 'hls');
  assert.ok(!/source-labelled/.test(streams[0].title));
  assert.ok(!client.calls.some(function (call) { return /720\.m3u8$/.test(call.url); }));
});

test('FilmixTV requires both credentials and exact runtime before any account request', async function () {
  var cases = [
    { meta: movie, cfg: tvAccount },
    { meta: Object.assign({}, movie, { runtimeSeconds: 3600 }), cfg: { filmixTvToken: tvAccount.filmixTvToken } },
    { meta: Object.assign({}, movie, { runtimeSeconds: 3600 }), cfg: { filmixTvHash: tvAccount.filmixTvHash } },
    { meta: Object.assign({}, movie, { runtimeSeconds: 3600 }), cfg: { filmixTvToken: 'bad\r\nheader', filmixTvHash: tvAccount.filmixTvHash } }
  ];
  for (var i = 0; i < cases.length; i++) {
    var client = accountFixture(cases[i].meta, [], {});
    var streams = await filmix.resolve(cases[i].meta, null, null, cases[i].cfg, client);
    assert.equal(streams.length, 1);
    assert.equal(streams[0].quality, '480p');
    assert.ok(client.calls.every(function (call) { return /^http:\/\/filmixapp\.cyou\//.test(call.url); }));
  }
});

test('FilmixTV selects exact series season and episode metadata', async function () {
  var meta = Object.assign({}, series, { runtimeSeconds: 2700 });
  var url = 'https://cdn.example/s02e03/index.m3u8';
  var data = { Dub: { 'season-1': { season: 1, episodes: { e3: { episode: 3, files: [{ quality: 1080, url: 'https://cdn.example/wrong-season.m3u8' }] } } }, 'season-2': { season: 2, episodes: { e2: { episode: 2, files: [{ quality: 1080, url: 'https://cdn.example/wrong-episode.m3u8' }] }, e3: { episode: 3, files: [{ quality: 1080, url: url }] } } } } };
  var client = accountFixture(meta, data, { [url]: vod(2700) });
  var streams = await filmix.resolve(meta, 2, 3, tvAccount, client);
  assert.equal(streams.length, 1);
  assert.equal(streams[0].url, url);
  assert.ok(!client.calls.some(function (call) { return /wrong-/.test(call.url); }));
  data.Dub['season-2'].episodes.e3.episode = 4;
  assert.deepEqual(filmix.tvCandidates(data, meta, 2, 3), []);
});

test('FilmixTV bounds HD choices, rejects premium MP4 previews, and keeps only HTTPS HLS', function () {
  var files = [
    { quality: 2160, url: 'https://cdn.example/4k.m3u8' },
    { quality: 2160, url: 'https://cdn.example/4k-other.m3u8' },
    { quality: 1080, url: 'https://cdn.example/1080.m3u8' },
    { quality: 2160, url: 'https://cdn.example/premium-preview_2160.mp4' },
    { quality: 1080, url: 'http://cdn.example/insecure.m3u8' },
    { quality: 1080, url: 'https://user:secret@cdn.example/credentials.m3u8' },
    { quality: 1080, url: 'https://api.filmix.tv/api-fx/credential-host.m3u8' },
    { quality: 720, url: 'https://cdn.example/720.m3u8' }
  ];
  var selected = filmix.tvCandidates([{ voiceover: 'Dub', files: files }], movie);
  assert.deepEqual(selected.map(function (item) { return item.quality; }), [2160, 1080]);
  assert.deepEqual(selected.map(function (item) { return item.url; }), ['https://cdn.example/4k.m3u8', 'https://cdn.example/1080.m3u8']);
});

test('rechecks the post identity and rejects a mismatching response', async function () {
  var client = requestFixture([result(81482, 'Interstellar', 2014)], postResult(999, movie, {
    movie: [{ link: 'https://cdn.example/movie_[480].mp4' }]
  }));
  assert.deepEqual(await filmix.resolve(movie, null, null, {}, client), []);
  client = requestFixture([result(81482, 'Interstellar', 2014)], postResult(81482, Object.assign({}, movie, { year: 2024 }), {
    movie: [{ link: 'https://cdn.example/movie_[480].mp4' }]
  }));
  assert.deepEqual(await filmix.resolve(movie, null, null, {}, client), []);
});

test('empty/locked player links produce no fabricated candidates', function () {
  assert.deepEqual(filmix.candidates(postResult(1, movie, { movie: [], playlist: [], trailer: [] }), movie), []);
  assert.deepEqual(filmix.candidates(postResult(1, series, { playlist: [] }), series, 1, 1), []);
});

test('stops invalid episode requests before any network call', async function () {
  var client = requestFixture([], {});
  assert.deepEqual(await filmix.resolve(series, -1, 1, {}, client), []);
  assert.deepEqual(await filmix.resolve(series, 1, 0, {}, client), []);
  assert.equal(client.calls.length, 0);
});
