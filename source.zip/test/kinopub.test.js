'use strict';
var test = require('node:test');
var assert = require('node:assert/strict');
var kinopub = require('../src/kinopub');
var movie = { type: 'movie', title: 'Интерстеллар', originalTitle: 'Interstellar', year: 2014, imdb: 'tt0816692' };
var series = { type: 'tv', title: 'Во все тяжкие', originalTitle: 'Breaking Bad', year: 2008, imdb: 'tt0903747' };
var TOKEN = 'my-own-test-access-token';
function item(meta, id) {
  return { id: id || 10, title: meta.title + ' / ' + meta.originalTitle, type: meta.type === 'tv' ? 'serial' : 'movie', year: meta.year, imdb: Number(meta.imdb.slice(2)) };
}
function fixture(search, detail, links) {
  var calls = [];
  return { calls: calls, request: function (url, options) {
    calls.push({ url: url, options: options });
    if (/\/items\/search\?/.test(url)) return Promise.resolve({ items: search });
    if (/\/items\/media-links\?/.test(url)) return Promise.resolve(links);
    return Promise.resolve({ item: detail });
  } };
}
function file(quality, codec) {
  return { quality: quality + 'p', w: Math.round(quality * 16 / 9), h: quality, codec: codec || 'h264', urls: { hls4: 'https://cdn.example/' + quality + '.m3u8?signature=public-test', http: 'https://cdn.example/' + quality + '.mp4' } };
}

test('KinoPub is completely inactive without the user account token', async function () {
  var client = fixture([], {}, {});
  assert.deepEqual(await kinopub.resolve(movie, null, null, {}, client), []);
  assert.equal(client.calls.length, 0);
});

test('KinoPub refuses insecure or credential-bearing API addresses before any request', async function () {
  for (var api of ['http://api.srvkp.com', 'https://user:password@api.srvkp.com', 'https://api.srvkp.com/?token=x']) {
    var client = fixture([], {}, {});
    await assert.rejects(kinopub.resolve(movie, null, null, { kinopubToken: TOKEN, kinopubApi: api }, client), /HTTPS/);
    assert.equal(client.calls.length, 0);
  }
});

test('KinoPub matches translated slash titles but rejects remakes, wrong type, and conflicting IMDb', function () {
  var entry = item(movie);
  delete entry.imdb;
  assert.ok(kinopub.matchScore(entry, movie) > 0);
  assert.equal(kinopub.matchScore(Object.assign({}, entry, { year: 2024 }), movie), -1);
  assert.equal(kinopub.matchScore(Object.assign({}, entry, { type: 'serial' }), movie), -1);
  assert.equal(kinopub.matchScore(Object.assign({}, entry, { imdb: 1234567 }), movie), -1);
});

test('KinoPub gets links only for the exact requested episode, preserving 4K file metadata', async function () {
  var entry = item(series);
  entry.seasons = [{ number: 2, episodes: [{ number: 3, id: 999 }, { number: 1, id: 201 }] }, { number: 1, episodes: [{ number: 1, id: 101 }] }];
  var client = fixture([item(series)], entry, { files: [file(1080), file(2160, 'hevc')], subtitles: [{ lang: 'rus', url: 'https://cdn.example/subs.vtt' }] });
  var streams = await kinopub.resolve(series, 2, 1, { kinopubToken: TOKEN }, client);
  assert.equal(client.calls.length, 3);
  assert.match(client.calls[1].url, /nolinks=1/);
  assert.match(client.calls[2].url, /mid=201$/);
  assert.equal(streams[0].quality, '2160p');
  assert.equal(streams[0].metadataVerified, true);
  assert.match(streams[0].codecSummary, /hevc 3840x2160/);
  assert.equal(streams[0].subtitles[0].language, 'rus');
});

test('KinoPub keeps account authorization on API headers and out of CDN URLs or headers', async function () {
  var entry = item(movie);
  entry.videos = [{ number: 1, id: 500 }];
  var client = fixture([entry], entry, { files: [file(1080)] });
  var streams = await kinopub.resolve(movie, null, null, { kinopubToken: TOKEN }, client);
  assert.equal(streams.length, 1);
  client.calls.forEach(function (call) {
    assert.ok(call.url.startsWith('https://api.srvkp.com/v1/'));
    assert.equal(call.options.headers.Authorization, 'Bearer ' + TOKEN);
    assert.equal(call.options.sensitive, true);
    assert.ok(!call.url.includes(TOKEN));
  });
  assert.deepEqual(streams[0].headers, {});
  assert.ok(!JSON.stringify(streams).includes(TOKEN));
});

test('KinoPub does not substitute array positions for missing episode numbers', async function () {
  var entry = item(series);
  entry.seasons = [{ number: 1, episodes: [{ number: 2, id: 102 }, { id: 103 }] }];
  var client = fixture([entry], entry, { files: [file(2160)] });
  assert.deepEqual(await kinopub.resolve(series, 1, 1, { kinopubToken: TOKEN }, client), []);
  assert.equal(client.calls.length, 2);
});

test('KinoPub rejects a detail item that differs from the matched search item', async function () {
  var entry = item(movie, 22);
  entry.videos = [{ number: 1, id: 99 }];
  var client = fixture([item(movie, 10)], entry, { files: [file(1080)] });
  assert.deepEqual(await kinopub.resolve(movie, null, null, { kinopubToken: TOKEN }, client), []);
  assert.equal(client.calls.length, 2);
});

test('KinoPub bounds variants and excludes malformed, insecure, or account-token playback URLs', function () {
  var files = [file(2160), file(1440), file(1080), file(720)];
  assert.equal(kinopub.streamsFromLinks({ files: files }, {}, TOKEN).length, 3);
  files[0].urls = { hls: 'http://cdn.example/2160.m3u8' };
  files[1].urls = { hls: 'https://cdn.example/1440.m3u8?access_token=account-secret' };
  files[2].urls = { hls: 'https://cdn.example/' + TOKEN + '/1080.m3u8' };
  files[3].quality = 'unknown'; files[3].w = 0; files[3].h = 0;
  assert.deepEqual(kinopub.streamsFromLinks({ files: files }, {}, TOKEN), []);
});

test('KinoPub safely reports token failures without echoing provider response or transport data', async function () {
  var bad = { request: function () { return Promise.reject(new Error('Rejected ' + TOKEN)); } };
  await assert.rejects(kinopub.resolve(movie, null, null, { kinopubToken: TOKEN }, bad), function (error) {
    return error.providerSafe === true && !error.message.includes(TOKEN) && /Account\/API request failed/.test(error.message);
  });
  var denied = { request: function () { return Promise.resolve({ status: 401, error: TOKEN }); } };
  await assert.rejects(kinopub.resolve(movie, null, null, { kinopubToken: TOKEN }, denied), function (error) { return error.providerSafe && !error.message.includes(TOKEN); });
});

test('KinoPub can use older selected-video links without fetching unrelated media', async function () {
  var entry = item(movie);
  entry.videos = [{ number: 1, files: [file(1080)] }];
  var client = fixture([entry], entry, {});
  var streams = await kinopub.resolve(movie, null, null, { kinopubToken: TOKEN }, client);
  assert.equal(streams.length, 1);
  assert.equal(client.calls.length, 2);
});

test('KinoPub uses exact API dimensions to reject overstated 4K labels and recognize cropped 1080p', function () {
  assert.equal(kinopub.fileQuality({ quality: '2160p', w: 1920, h: 1080 }), '1080p');
  assert.equal(kinopub.fileQuality({ quality: '1080p', w: 1920, h: 800 }), '1080p');
  assert.equal(kinopub.fileQuality({ quality: '2160p', w: 3840, h: 1600 }), '2160p');
});
