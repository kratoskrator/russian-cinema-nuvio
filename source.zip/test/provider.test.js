'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const http=require('../src/http');
const u=require('../src/utils');
const code=fs.readFileSync(require('node:path').join(__dirname,'../src/index.js'),'utf8');
function harness(options={}) {
 const calls=[],warnings=[],modules={};
 const cfg=options.settings||{};
 const network={session:http.session,request:async(url,init)=>{
  calls.push({url,init});
  if(url.startsWith('https://api.themoviedb.org/'))return {name:'Во все тяжкие',original_name:'Breaking Bad',first_air_date:'2008-01-20',external_ids:{imdb_id:'tt0903747'}};
  if(options.responses&&options.responses[url])return options.responses[url];
  const data=Array(64).fill(0);data.splice(4,4,102,116,121,112);
  return {status:206,body:'',contentType:'video/mp4',contentRange:'bytes 0-63/10000000',data};
 }};
 for(const name of ['filmix','seasonvar'])modules[name]={resolve:async(meta,season,episode,cfg,client)=>{
  calls.push({source:name,meta,season,episode,cfg});
  if(options.fail===name)throw new Error('private https://host.test/?token=fixture-secret');
  return options[name]||[{url:'https://cdn.test/'+name+'.mp4',quality:'480p',title:'Русская озвучка',headers:{Referer:'https://'+name+'.test/'}}];
 }};
 const context=vm.createContext({module:{exports:{}},TMDB_API_KEY:options.key===undefined?'fixture-key':options.key,SCRAPER_SETTINGS:cfg,console:{warn:msg=>warnings.push(msg)},require:name=>name==='./utils'?u:name==='./http'?network:modules[name.slice(2)]});
 vm.runInContext(code,context);
 return {plugin:context.module.exports,calls,warnings};
}
test('one provider combines both sources and labels the requested episode',async()=>{
 const h=harness();const result=await h.plugin.getStreams('1396','tv',2,3);
 assert.equal(result.length,2);
 assert.ok(result.every(x=>x.name==='Russian Cinema'&&x.title.includes('S2E3')));
 assert.match(result[0].title,/Filmix/);assert.match(result[1].title,/Seasonvar/);
 assert.ok(h.calls[0].url.includes('language=ru-RU'));
 assert.equal(h.calls.find(x=>x.source==='filmix').meta.imdb,'tt0903747');
 assert.equal(h.calls.filter(x=>x.init&&x.init.binary&&x.init.headers.Range==='bytes=0-63').length,2);
});
test('a failed source leaves results from the other source and sanitizes diagnostics',async()=>{
 const h=harness({fail:'filmix'});const result=await h.plugin.getStreams('1396','series',1,1);
 assert.equal(result.length,1);assert.match(result[0].title,/Seasonvar/);
 assert.equal(h.warnings.length,1);assert.ok(!h.warnings[0].includes('fixture-secret'));
});
test('movies use Filmix and never query the series-only source',async()=>{
 const h=harness();assert.equal((await h.plugin.getStreams('27205','movie')).length,1);
 assert.ok(!h.calls.some(x=>x.source==='seasonvar'));
});
test('duplicate URLs and HTML responses are excluded from the stream list',async()=>{
 const stream={url:'https://cdn.test/duplicate.mp4'};
 const h=harness({filmix:[stream],seasonvar:[stream],responses:{'https://cdn.test/duplicate.mp4':{status:200,body:'',contentType:'text/html'}}});
 assert.equal((await h.plugin.getStreams('1396','tv',1,1)).length,0);
 assert.equal(h.calls.filter(x=>x.url===stream.url).length,1);
});
test('HLS sources require a real playlist before being returned',async()=>{
 const url='https://cdn.test/master.m3u8';const h=harness({filmix:[{url}],seasonvar:[],responses:{[url]:{body:'<html>expired</html>',status:200,contentType:'text/html'}}});
 assert.equal((await h.plugin.getStreams('1396','tv',1,1)).length,0);
 const valid=harness({filmix:[{url}],seasonvar:[],responses:{[url]:{body:'#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=100000\nindex.m3u8',status:200}}});
 assert.equal((await valid.plugin.getStreams('1396','tv',1,1)).length,1);
 assert.equal(valid.calls.find(x=>x.url===url).init.method,'GET');
});
test('invalid requests and missing metadata credentials never start a source lookup',async()=>{
 const h=harness({key:''});
 for(const args of [['bad','movie'],['1396','tv',1,0],['1396','tv',-1,1],['1396','movie']])assert.equal((await h.plugin.getStreams(...args)).length,0);
 assert.equal(h.calls.length,0);
});
test('settings override the injected TMDB key and keep bearer tokens out of source requests',async()=>{
 const token='x'.repeat(80);const h=harness({settings:{tmdbApiKey:token}});
 await h.plugin.getStreams('1396','tv',1,1);
 assert.equal(h.calls[0].init.bearer,token);assert.ok(!h.calls[0].url.includes(token));
 assert.ok(h.calls.filter(x=>x.init&&x.init.binary).every(x=>!x.init.bearer));
 const settings=await h.plugin.onSettings();assert.equal(settings.find(x=>x.key==='tmdbApiKey').isPassword,true);
});
